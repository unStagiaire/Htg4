import { createFileRoute } from "@tanstack/react-router";
import { StudyApp } from "@/components/study/StudyApp";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <StudyApp />;
}
