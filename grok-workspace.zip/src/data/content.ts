export type Tone = "crisis" | "terror" | "demo" | "geo";
export type Chapter = "crise" | "regimes" | "monde";

export type Lesson = {
  id: string;
  chapter: Chapter;
  title: string;
  tone: Tone;
  remember: string;
  points: string[];
};

export type GlossaryEntry = {
  id: string;
  term: string;
  def: string;
  chapter: Chapter;
  example?: string;
};

export type TimelineEvent = {
  id: string;
  when: string;
  sort: number;
  title: string;
  text: string;
  tone: Tone;
};

export type Figure = { id: string; n: string; label: string };
export type Trap = { id: string; wrong: string; right: string };
export type CompareRow = { id: string; label: string; it: string; de: string; su: string };

export type Story = {
  id: string;
  date: string;
  title: string;
  tone: Tone;
  place: string;
  prompts: string[];
  beats: string[];
  copie: string;
};

export type RqpPart = {
  title: string;
  subs: { title: string; details: string[] }[];
};

export type RqpSubject = {
  id: string;
  tag: "Mixte" | "Chapitre 1" | "Chapitre 2";
  question: string;
  define: string[];
  intro: string;
  parts: RqpPart[];
  conclusion: string;
};

export type QuizItem = {
  id: string;
  tag: "date" | "notion" | "fait";
  q: string;
  choices: [string, string, string, string];
  answer: 0 | 1 | 2 | 3;
  why: string;
};

export const FIGURES: Figure[] = [
  { id: "x6", n: "×6", label: "Cours des actions, 1926-1929, sans lien avec la valeur réelle" },
  { id: "12", n: "12 M", label: "Actions sans acheteur, jeudi noir, 24 octobre 1929" },
  { id: "16", n: "16 M", label: "Actions encore vendues, mardi noir, 29 octobre 1929" },
  { id: "24", n: "24 Mds $", label: "Prêtés par six grandes banques pour la spéculation" },
  { id: "pib", n: "−30 %", label: "PIB américain entre 1929 et 1933" },
  { id: "ind", n: "−45 %", label: "Production industrielle américaine, 1929-1933" },
  { id: "exp", n: "−25 %", label: "Exportations mondiales" },
  { id: "chom", n: "25 %", label: "Américains sans emploi en 1933, environ 13 millions" },
  { id: "sal", n: "−40 %", label: "Baisse des salaires aux États-Unis, cercle vicieux" },
  { id: "al", n: "−50 %", label: "Valeur des exportations d’Amérique latine, 1929-1932" },
  { id: "neuf", n: "9 M", label: "Chômeurs américains encore en 1939, après le New Deal" },
  { id: "mat", n: "+7 à 15 %", label: "Hausse des salaires, accords Matignon, 7-8 juin 1936" },
];

export const LESSONS: Lesson[] = [
  {
    id: "c-intro",
    chapter: "crise",
    title: "Problématique, contexte, notions",
    tone: "crisis",
    remember:
      "La crise de 1929 casse les équilibres nés du libéralisme des années 1920 et oblige l’État à prendre une place nouvelle.",
    points: [
      "Problématique du chapitre : comment la crise de 1929 bouleverse-t-elle les équilibres économiques et sociaux et fragilise-t-elle les modèles économiques en renforçant la place de l’État dans la société ?",
      "Contexte des [[années 1920]] : insouciance, retour de la consommation après les privations de la Grande Guerre, volonté d’oublier les traumatismes, triomphe du {{libéralisme}} (libre-échange).",
      "Notions à définir dès l’introduction : {{crise économique}}, {{crise sociale}}, {{dépression}}, {{interventionnisme}}, {{protectionnisme}}, {{krach boursier}}, {{bulle spéculative}}.",
      "Le sujet mêle toujours trois échelles : les États-Unis (épicentre), l’Europe, l’Amérique latine — et deux dimensions : économique puis politique.",
    ],
  },
  {
    id: "c-def",
    chapter: "crise",
    title: "Les trois définitions du cours",
    tone: "crisis",
    remember:
      "Économique = production qui tombe. Sociale = vie qui se dégrade. 1929 = le krach des 24 et 29 octobre.",
    points: [
      "{{Crise économique}} : baisse de la production et des investissements, donc baisse des salaires et hausse des faillites. La conjoncture se dégrade, le chômage monte.",
      "{{Crise sociale}} : les conditions de vie se détériorent (chômage, salaires, endettement) et la population s’appauvrit.",
      "{{Crise de 1929}} : la crise qui suit le {{krach boursier}} du [[24 octobre 1929]] (jeudi noir) et du [[29 octobre 1929]] (mardi noir).",
      "{{Dépression}} : ce n’est plus un accident bref. C’est une crise longue, profonde, qui s’auto-entretient.",
    ],
  },
  {
    id: "c-causes",
    chapter: "crise",
    title: "Causes : une économie américaine déjà fragile",
    tone: "crisis",
    remember:
      "Surproduction + bulle du crédit + banques peu contrôlées + monde dépendant des États-Unis : le krach ne peut pas rester américain.",
    points: [
      "{{Surproduction}} agricole : mécanisation forte, fermiers surendettés. Surproduction industrielle de masse : automobile, électroménager, alimentaire. On produit plus que la demande.",
      "{{Bulle spéculative}} : entre [[1926]] et [[1929]], le cours des actions est multiplié par six, sans rapport avec la valeur réelle des entreprises. Beaucoup d’Américains achètent à crédit.",
      "Système bancaire fragile : crédit à court terme, peu contrôlé. Six grandes banques ont prêté [[24 milliards de dollars]] pour financer la spéculation.",
      "Le monde dépend des États-Unis : principaux créanciers de l’Europe, et grands importateurs de la production d’Amérique latine. Un choc à Wall Street devient un choc mondial.",
    ],
  },
  {
    id: "c-krach",
    chapter: "crise",
    title: "Du krach à la crise financière",
    tone: "crisis",
    remember:
      "Jeudi noir : 12 millions d’actions. Mardi noir : 16 millions. Puis les banques ferment le crédit.",
    points: [
      "[[24 octobre 1929]], jeudi noir : 12 millions d’actions mises en vente sans acheteur.",
      "[[29 octobre 1929]], mardi noir : 16 millions d’actions supplémentaires. Les cours s’effondrent. C’est une crise de confiance.",
      "Les banques cessent de prêter et font faillite. Début de la crise financière : faillites bancaires, effondrement du crédit, contraction des investissements.",
      "Ordre à réciter : bulle → krach → crise de confiance → crise financière → crise économique → crise sociale.",
    ],
  },
  {
    id: "c-dep",
    chapter: "crise",
    title: "La dépression et le cercle vicieux",
    tone: "crisis",
    remember:
      "Entre 1929 et 1933 : PIB −30 %, industrie −45 %, exportations mondiales −25 %, chômage américain 25 %, salaires −40 %.",
    points: [
      "Entre [[1929 et 1933]], le PIB américain chute d’environ 30 %, la production industrielle de 45 %, les exportations mondiales de 25 %.",
      "La demande tombe, donc la demande de travail tombe : les entreprises ferment ou licencient. En [[1933]], 25 % des Américains sont sans emploi (près de 13 millions, un quart de la population active).",
      "Les salaires baissent d’environ 40 %. La consommation intérieure baisse encore : le cercle vicieux de la {{dépression}} est enclenché.",
      "Dans les campagnes, chute des prix et {{Dust Bowl}} : les fermiers sont ruinés, l’exode rural est massif.",
    ],
  },
  {
    id: "c-monde",
    chapter: "crise",
    title: "Une crise sociale mondiale, trois piliers détruits",
    tone: "crisis",
    remember:
      "La crise détruit la production, le commerce international et l’étalon-or. Le libéralisme est remis en cause.",
    points: [
      "États-Unis : multiplication des {{Hoovervilles}} (bidonvilles de chômeurs). Manifestations de chômeurs à New York en [[1930]]. Marches de la faim au Royaume-Uni en [[1932]].",
      "La crise frappe l’Amérique latine (exportations de matières premières), l’Europe et l’Asie. Paupérisation, troubles sociaux et politiques, montée des contestations.",
      "Entre [[1929 et 1933]], trois piliers de l’économie mondiale sont détruits : la production, le commerce international, le système monétaire fondé sur l’{{étalon-or}}.",
      "Conséquence politique du chapitre : remise en cause du {{libéralisme}} et du rôle de l’État. Trois noms à associer : New Deal (États-Unis), Front populaire (France), Estado Novo (Brésil).",
    ],
  },
  {
    id: "c-al",
    chapter: "crise",
    title: "Amérique latine et Estado Novo",
    tone: "terror",
    remember:
      "Exportations −50 % entre 1929 et 1932. Les régimes libéraux tombent. Au Brésil, Vargas instaure l’Estado Novo en 1937.",
    points: [
      "Entre [[1929 et 1932]], la valeur des exportations latino-américaines chute de 50 % en moyenne. L’activité se contracte, le chômage monte.",
      "Troubles sociaux (manifestations, grèves) et instabilité politique : plusieurs régimes libéraux s’effondrent, souvent au profit de régimes autoritaires.",
      "[[1937]] : Getúlio Vargas instaure l’{{Estado Novo}} au Brésil, dictature appuyée sur la propagande et le nationalisme d’État.",
      "Politique de {{développement autocentré}} : industrialisation planifiée, entreprises d’{{économie mixte}}, pétrole, minerais, industrie lourde. L’État intervient davantage, la démocratie recule.",
    ],
  },
  {
    id: "c-newdeal",
    chapter: "crise",
    title: "États-Unis : le New Deal",
    tone: "demo",
    remember:
      "Roosevelt, élu en 1932, inspiré par Keynes. 1er New Deal = urgence (1933-1934). 2e New Deal = social (1935-1938). En 1939, encore 9 millions de chômeurs.",
    points: [
      "Effondrement bancaire, misère, tensions. [[1932]] : élection de Franklin D. Roosevelt. Le New Deal est inspiré par {{Keynes}} : l’État intervient.",
      "1er New Deal [[1933-1934]], l’urgence : séparation des banques de dépôt et des banques d’affaires, contrôle des marchés financiers, agences fédérales, grands travaux pour l’emploi ({{TVA}}, {{PWA}}).",
      "2e New Deal [[1935-1938]] : lois sur les salaires et les conditions de travail, extension du droit syndical, {{Social Security Act}} ([[1935]]) qui crée un système d’assurances sociales.",
      "Relance et amélioration sociales, mais résultat limité : en [[1939]], environ 9 millions de chômeurs. Phrase de bilan : l’intervention atténue la crise sans en effacer les effets.",
    ],
  },
  {
    id: "c-fp",
    chapter: "crise",
    title: "France : le Front populaire",
    tone: "demo",
    remember:
      "6 février 1934, la rue. Avril-mai 1936, Blum. 7-8 juin, Matignon. Congés payés et 40 heures. Blum démissionne en 1937, mais l’État social est né.",
    points: [
      "La crise atteint la France au début des [[années 1930]] : chômage de masse, tensions, montée du populisme, instabilité. Émeutes du [[6 février 1934]].",
      "Élections d’[[avril-mai 1936]] : le Front populaire ({{SFIO}}, radicaux, Parti communiste), dirigé par Léon Blum, arrive au pouvoir.",
      "Accords Matignon [[7-8 juin 1936]], entre le patronat ({{CGPF}}) et les syndicats ({{CGT}}) : salaires +7 à 15 %, conventions collectives, liberté syndicale.",
      "Lois sociales de [[juin 1936]] : deux semaines de congés payés, semaine de 40 heures. Effet : consommation, loisirs, début de relance.",
      "Nationalisations stratégiques (chemins de fer, armement, aéronautique) et réforme de la Banque de France pour contrôler le crédit. Opposition du patronat. Démission de Blum en [[1937]]. Le Front populaire pose les bases de l’{{État social}}.",
    ],
  },
  {
    id: "c-bilan",
    chapter: "crise",
    title: "Bilan : deux réactions, puis la conclusion",
    tone: "demo",
    remember:
      "D’abord la déflation, qui aggrave. Ensuite la relance keynésienne, qui soulage sans guérir. En parallèle, des régimes autoritaires.",
    points: [
      "1re réaction, {{libéralisme}} : politique de {{déflation}} → baisse des salaires → aggravation de la crise.",
      "2e réaction, {{keynésianisme}} : relance, politique publique contre le chômage, protection sociale → dépenses de l’État → hausse de la fiscalité → reprise partielle. Exemples : New Deal, Front populaire.",
      "Contrôle des marchés intérieur (réglementation bancaire) et extérieur ({{protectionnisme}}, puis zones régionales pour protéger le commerce).",
      "Évolution politique : la crise économique et sociale déclenche des crises politiques, dans un climat de repli, de nationalisme et de montée de l’extrême droite. Des régimes autoritaires émergent.",
      "Conclusion du chapitre : la crise déstabilise durablement les démocraties libérales, aggrave la crise de confiance héritée de la Grande Guerre et nourrit l’extrême droite. Elle renforce le rôle de l’État, surtout dans l’économie ({{dirigisme}}, {{interventionnisme}}). Elle est une des raisons de l’émergence des pouvoirs autoritaires à l’échelle mondiale.",
    ],
  },
  {
    id: "r-aron",
    chapter: "regimes",
    title: "Définition du totalitarisme (Raymond Aron)",
    tone: "terror",
    remember:
      "Dictature qui prend toute la société, vie privée comprise. Cinq traits ensemble : parti, idéologie, terreur, médias, économie de conquête.",
    points: [
      "Citation du cours : un régime totalitaire est un régime dictatorial qui a une emprise sur toute la société, même la sphère privée. On ne parle de totalitarisme que s’il réunit les cinq caractéristiques.",
      "1. Un appareil d’État contrôlé par un {{parti unique}}, dirigé par un chef charismatique ({{culte de la personnalité}}) : lien direct entre le peuple et le chef.",
      "2. Une idéologie d’État qui promet un {{homme nouveau}}, et qui justifie l’encadrement, voire l’{{embrigadement}}.",
      "3. Un appareil policier qui recourt à la terreur, y compris au-delà des seuls opposants.",
      "4. Le monopole des moyens de communication de masse : {{propagande}} et {{censure}}.",
      "5. Un {{dirigisme}} économique visant l’{{autarcie}}, pensé comme impossible sans élargir le territoire : militarisation et conquête.",
      "Conséquence annoncée par le cours : opposition de deux modèles, démocratie contre totalitarisme, et bouleversement de l’ordre européen.",
      "Problématique : comment les régimes totalitaires, antagonistes ou alliés, ont-ils déstabilisé les sociétés européennes ?",
    ],
  },
  {
    id: "r-ideo",
    chapter: "regimes",
    title: "Trois idéologies, trois hommes nouveaux, trois paquets de lois",
    tone: "terror",
    remember:
      "URSS : travailleur internationaliste. Italie : homme fort au service de l’État. Allemagne : Aryen, racisme et espace vital.",
    points: [
      "URSS, marxisme-léninisme : communisme donc internationaliste, dictature du prolétariat présentée comme une « vraie démocratie », violence de classe. L’homme nouveau est un travailleur, ouvrier et kolkhozien.",
      "Italie, fascisme : nationaliste, l’État au centre, parallèle avec la Rome antique. L’homme nouveau est fort, athlétique, discipliné, au service de la patrie.",
      "Allemagne, nazisme. Texte fondateur : Mein Kampf. Nationalisme, anticommunisme, racisme et antisémitisme, pangermanisme, {{espace vital}} (Lebensraum), parallèle avec l’Empire (IIIe Reich). L’homme nouveau est un Aryen, blond aux yeux bleus, militaire.",
      "Mise en lois. URSS : collectivisation et lois de planification dès [[1929]]. Italie : lois fascistissimes [[1925-1926]] (État nationaliste et autoritaire), puis lois antisémites de [[1938]], tournant du rapprochement avec l’Allemagne. Allemagne : lois de Nuremberg le [[15 septembre 1935]], fin de la citoyenneté des Juifs.",
    ],
  },
  {
    id: "r-pouvoir",
    chapter: "regimes",
    title: "Parti unique, prise du pouvoir, culte du chef",
    tone: "terror",
    remember:
      "Staline s’impose en 1927-1928, Mussolini en 1922, Hitler chancelier le 30 janvier 1933 et seul maître en août 1934.",
    points: [
      "URSS : révolution bolchevique [[1917]], création de l’URSS en [[1922]]. Le {{PCUS}} est créé en [[1918]] et unique à partir de [[1923]], après l’éviction des opposants. [[1927]] : purge des trotskystes, Staline refuse de négocier avec Trotsky. [[1928]] : Staline prend la tête du parti et de l’URSS.",
      "Italie : {{Parti national fasciste}} créé en [[1921]], unique en [[1925]]. Marche sur Rome en [[1922]] : 26 000 fascistes. Le roi nomme Mussolini président du Conseil. Il tient l’exécutif, mais il doit compter avec le roi.",
      "Allemagne : {{NSDAP}} (parti national-socialiste des travailleurs allemands) créé en [[1920]], unique en [[1933]]. En juillet [[1932]], il est le premier parti au Reichstag. Hindenburg nomme Hitler chancelier le [[30 janvier 1933]]. Mort d’Hindenburg le [[2 août 1934]] : fin de la présidence, Hitler seul au pouvoir.",
      "Chefs et surnoms du cours : Staline (1879-1953), le « Vodj », petit père des peuples, image rassurante. Mussolini (1883-1945), le « Duce » (le guide), salut fasciste, leader omniprésent. Hitler (1889-1945), le « Führer », chef de guerre « qui apporte la lumière ».",
    ],
  },
  {
    id: "r-eco",
    chapter: "regimes",
    title: "Une économie dirigiste au service de l’idéologie",
    tone: "terror",
    remember:
      "L’autarcie ne tient pas toute seule : elle pousse à militariser et à conquérir.",
    points: [
      "URSS : collectivisation des terres, élimination des {{koulaks}}, mise en commun dans les {{kolkhozes}}, nationalisation de l’industrie. But : puissance agricole et industrielle. À partir de [[1929]], le cours parle d’un totalitarisme de « haute intensité », une marche forcée.",
      "Italie : politique de grands chantiers (assèchement des marais, villes nouvelles), « guerre du blé ». But : renforcer le marché intérieur pour atteindre l’{{autarcie}}.",
      "Allemagne : élimination des Juifs de l’économie (loi de [[1938]]), militarisation de l’industrie (Ruhr) pour préparer la conquête de l’espace vital.",
      "Phrase de copie : le dirigisme n’est pas une politique de prospérité. C’est l’économie mise au service du projet idéologique.",
    ],
  },
  {
    id: "r-soc",
    chapter: "regimes",
    title: "Propagande, censure, jeunesse, loisirs",
    tone: "terror",
    remember:
      "On fabrique l’adhésion : culte du chef, médias unique, jeunesse encadrée, loisirs surveillés. L’embrigadement reste pourtant incomplet.",
    points: [
      "Culte. Staline : le Vodj. Mussolini : le Duce, grandeur de l’État, image de l’Italien père de famille, fort et engagé. Hitler : le Führer, mythe de la race aryenne, aigle du Reich, parti protecteur.",
      "Censure. URSS : {{stakhanovisme}}, le meilleur ouvrier ou paysan comme modèle. Italie : censure, image imposée. Allemagne : censure de la presse, autodafés, affiche de la famille aryenne.",
      "Jeunesse. URSS : {{Komsomol}}, formation marxiste-léniniste, travail, loisirs, alphabétisation. Italie : {{Balilla}}, admiration du Duce, service militaire et discipline. Allemagne : Jeunesses hitlériennes, exercice physique pour « purger », peu d’éducation intellectuelle afin d’éviter la critique du régime.",
      "Loisirs. Italie : {{Opera Nazionale Dopolavoro}} (sport, théâtre, jeux), mais pouvoir limité par le roi et le pape. Allemagne : valorisation du sport, {{JO de Berlin}} en [[1936]], succès de propagande limité par la victoire de l’athlète américain Jesse Owens.",
    ],
  },
  {
    id: "r-police",
    chapter: "regimes",
    title: "Milices, polices politiques, purges",
    tone: "terror",
    remember:
      "D’abord la milice du parti, ensuite la police légale. La violence sert aussi à faire taire l’intérieur du parti.",
    points: [
      "But : faire taire les oppositions réelles et possibles, montrer une société unie. La violence est d’abord celle des partis et de leurs milices, puis celle d’une police politique qui récupère la violence « légitime ». Les milices, elles, ne disparaissent pas.",
      "Italie : les squadristes, ou chemises noires, appuient la prise du pouvoir en [[1922]] et chassent les opposants dans les campagnes, jusque par la torture. {{OVRA}} créée en [[1927]] : 11 inspectorats, réseau d’informateurs, surveillance des « subversifs », de la presse hostile et des groupes étrangers. Arrestations arbitraires, camps de travail (souvent des carrières de sel). Supprimée en [[1945]].",
      "Allemagne : les {{SA}} (Sturmabteilung, chemises brunes) sont créées en [[1921]] par Hitler à Munich, service d’ordre du parti. Leur rôle diminue à partir de [[1934]]. La Gestapo est fondée en [[1933]] par Hermann Göring et développée par Heinrich Himmler : opposants internes ou externes, réels ou supposés, puis adversaires dans les pays occupés. Arrestation, mort ou camp de concentration.",
      "URSS : le {{NKVD}} (Commissariat du peuple aux Affaires intérieures). Sa police politique est le {{Guépéou}} ([[1922-1934]]), intégré au NKVD après [[1934]]. Peur d’une intervention étrangère et des « ennemis de la Révolution ». Envoi massif au {{goulag}}.",
      "Purges internes. [[29-30 juin 1934]], Nuit des Longs Couteaux : environ 85 SA, dont leurs chefs, sont assassinés par les {{SS}} (Schutzstaffel) sur ordre d’Hitler, parce qu’une partie de la SA contestait sa ligne. [[1927]] : purge des trotskystes, Staline affirme son pouvoir.",
    ],
  },
  {
    id: "r-terreur",
    chapter: "regimes",
    title: "Terreur de masse et enracinement incomplet",
    tone: "terror",
    remember:
      "La terreur dépasse les opposants politiques. Mais ni le roi, ni les campagnes, ni l’armée ne sont jamais totalement soumis.",
    points: [
      "Le cours isole trois exposés de terreur : la Grande Terreur, la Nuit de Cristal, le massacre de Graziani.",
      "URSS : la famine organisée en Ukraine entre [[1932 et 1933]] frappe les paysans, pas seulement les militants. La Grande Terreur ([[1936-1938]], après l’assassinat de Kirov en décembre 1934) envoie des centaines de milliers de personnes au goulag ou à la mort, y compris des communistes.",
      "Allemagne : Nuit de Cristal, [[9-10 novembre 1938]], pogrom antijuif. L’Allemagne et l’URSS mettent au travail forcé les « ennemis du peuple » et commettent des crimes de masse.",
      "Italie : politique d’anéantissement en Éthiopie. Le massacre de Graziani suit l’attentat du [[19 février 1937]] à Addis-Abeba : représailles contre les civils.",
      "Enracinement incomplet. Italie : oppositions dans le Nord (villes et campagnes « rouges »), limites du roi et du pape. Allemagne : résistances dans toutes les catégories, y compris l’armée (plus tard, le complot du [[20 juillet 1944]] autour du maréchal Erwin von Witzleben). URSS : révoltes armées, et résistance passive (baisse des rendements). La culture traditionnelle dure via les grands-parents dans les campagnes.",
    ],
  },
  {
    id: "g-temps",
    chapter: "monde",
    title: "Pourquoi la géopolitique devient agressive",
    tone: "geo",
    remember:
      "L’idéologie veut s’exporter, l’autarcie veut du territoire : la société se militarise et les voisins deviennent des cibles.",
    points: [
      "Les régimes totalitaires ont une vision du monde à transmettre. Leur volonté d’autarcie renforce le besoin d’agrandir le territoire. D’où militarisation et tensions.",
      "[[1933-1935]] : montée des tensions. Réarmement de l’Allemagne, retrait de la SDN, essai d’alliance des démocraties avec l’URSS.",
      "[[1935-1936]] : basculement. Remilitarisation de la Rhénanie, guerre d’Espagne, fin du front de Stresa.",
      "[[1936-1939]] : marche vers la guerre. Anschluss, Sudètes, conférence de Munich, pacte germano-soviétique.",
    ],
  },
  {
    id: "g-stresa",
    chapter: "monde",
    title: "La fin du front de Stresa et le front fasciste",
    tone: "geo",
    remember:
      "1935 : France, Italie, Royaume-Uni unis contre Hitler. 1936 : Hitler joue la Rhénanie. L’Italie bascule vers Berlin.",
    points: [
      "Front de Stresa, [[1935]] : conférence entre la France, l’Italie et la Grande-Bretagne, unité affichée contre la menace hitlérienne.",
      "[[7 mars 1936]] : Hitler fait occuper la Rhénanie, zone allemande démilitarisée par le traité de Versailles. Il présente ce coup comme une réponse au pacte de non-agression franco-soviétique de [[1932]]. Coup de poker : l’armée allemande n’était pas prête à une guerre à l’Ouest.",
      "Axe Rome-Berlin, [[octobre 1936]] : protocole d’entente antibolchevique. Il prépare le pacte d’acier du [[22 mai 1939]], alliance automatique et offensive. C’est la fin réelle du front de Stresa.",
      "Pacte anti-Komintern : contre l’Internationale communiste. Signé le [[25 novembre 1936]] entre l’Allemagne et le Japon. L’Italie le rejoint le [[6 novembre 1937]], l’Espagne en [[1938]].",
    ],
  },
  {
    id: "g-host",
    chapter: "monde",
    title: "La montée des hostilités",
    tone: "geo",
    remember:
      "Espagne, Éthiopie, Albanie, Autriche, Tchécoslovaquie, puis le retournement : le pacte avec Staline pour avoir les mains libres en Pologne.",
    points: [
      "Guerre civile d’Espagne [[1936-1939]] : le cours la traite comme une répétition avant la guerre. L’Allemagne et l’Italie interviennent, les démocraties affichent la non-intervention.",
      "Après la conquête de l’Éthiopie ([[1935-1936]]), l’Italie, soutenue par l’Allemagne, envahit l’Albanie en [[avril 1939]] pour élargir son territoire.",
      "Espace vital et pangermanisme. [[12 mars 1938]] : la Wehrmacht entre en Autriche. [[13 mars 1938]] : l’Anschluss est proclamé. Plébiscite d’avril : 99,75 % pour l’annexion. L’Autriche devient l’Ostmark.",
      "[[12 septembre 1938]], discours de Nuremberg : Hitler revendique les Sudètes, région germanophone de Tchécoslovaquie. Le pays est démembré au lendemain de Munich. En [[mars 1939]], un coup de force met fin à la Tchécoslovaquie. Hitler se sent intouchable.",
      "[[23 août 1939]], pacte germano-soviétique (Ribbentrop et Molotov) : non-agression de dix ans. But allemand : la neutralité de l’URSS face à l’invasion de la Pologne. L’URSS accepte car elle soupçonne les démocraties de pousser Hitler vers l’est. Clauses secrètes : droits soviétiques sur la Finlande, les pays baltes, la Bessarabie, et partage de la Pologne.",
    ],
  },
  {
    id: "g-demo",
    chapter: "monde",
    title: "Des démocraties ambiguës, de la SDN à la guerre",
    tone: "geo",
    remember:
      "« Plus jamais ça » désarme les démocraties. Munich est une illusion. La Pologne, le 1er septembre 1939, les force enfin à réagir.",
    points: [
      "Les idées fascistes séduisent une partie des sociétés européennes via des partis. Les démocraties veulent éviter la guerre à tout prix, quitte à paraître faibles.",
      "Ingérence. Les partis communistes répondent à Moscou et sont souvent vus, à droite, comme des ennemis intérieurs. Les partis fascisants sont des antennes : British Union of Fascists d’Oswald Mosley ([[1932-1940]]), issu d’une entrevue avec Mussolini, impopulaire à la fin des années 1930. Parti populaire français de Jacques Doriot ([[1936-1945]]), ancien du PCF, anticommuniste, antisémite, fasciste, qui récupère d’anciens communistes, des socialistes et l’extrême droite des ligues dissoutes en 1936 (Faisceau, Croix-de-Feu, Action française de Maurras, fondée en 1898).",
      "SDN discréditée. Face à la Rhénanie en [[1936]], elle est inutile. Face à l’Éthiopie, elle désigne l’Italie comme agresseur mais, dans le cours, aucune sanction commerciale efficace n’est imposée.",
      "France et Royaume-Uni : pacifisme puissant, surtout le Front populaire à partir de [[1936]], d’où des réactions mesurées. Après la Rhénanie, la réaction française reste verbale : perte de confiance en Europe de l’Est et du centre, et de l’URSS. La France laisse aussi les mains libres à l’Italie.",
      "Conférence de Munich, [[septembre 1938]] : Hitler, Mussolini, Daladier, Chamberlain. Hitler obtient les territoires revendiqués. Pour Paris et Londres, illusion d’une paix. L’URSS, tenue à l’écart, se replie. La France est discréditée. Le Royaume-Uni accepte le fait accompli et signe avec l’Allemagne une déclaration de non-agression en septembre 1938.",
      "Depuis octobre 1938, l’Allemagne revendique Dantzig, ville libre. [[1er septembre 1939]] : invasion de la Pologne. [[3 septembre 1939]] : la France et le Royaume-Uni déclarent la guerre. Début de la Seconde Guerre mondiale. L’Italie, pas prête, négocie sans succès et n’entre en guerre qu’en [[juin 1940]].",
      "Conclusion : en voulant la paix à tout prix, les démocraties font des concessions contraires à leurs principes et se discréditent. Les régimes totalitaires apparaissent comme les seuls États forts, agissent dans l’impunité et décident l’ouverture de la guerre. C’est la crise polonaise qui oblige enfin à réagir.",
    ],
  },
];

export const GLOSSARY: GlossaryEntry[] = [
  { id: "crise-eco", term: "Crise économique", chapter: "crise", def: "Baisse de la production et des investissements, qui entraîne baisse des salaires et hausse des faillites. La conjoncture se dégrade, le chômage monte.", example: "1929-1933 : PIB américain −30 %." },
  { id: "crise-soc", term: "Crise sociale", chapter: "crise", def: "Détérioration des conditions de vie (chômage, salaires, endettement) qui appauvrit la population.", example: "Hoovervilles, marches de la faim." },
  { id: "depression", term: "Dépression", chapter: "crise", def: "Crise longue et profonde, qui s’auto-entretient : moins de salaires, moins de consommation, encore moins d’emplois.", example: "La Grande Dépression après 1929." },
  { id: "krach", term: "Krach boursier", chapter: "crise", def: "Effondrement brutal des cours. Ici, Wall Street les 24 et 29 octobre 1929.", example: "Jeudi noir, mardi noir." },
  { id: "bulle", term: "Bulle spéculative", chapter: "crise", def: "Hausse des prix déconnectée de la valeur réelle, nourrie par l’achat à crédit. Elle finit par éclater.", example: "Actions ×6 entre 1926 et 1929." },
  { id: "liberalisme", term: "Libéralisme", chapter: "crise", def: "Doctrine du libre-échange et de l’État en retrait. C’est le cadre des années 1920, remis en cause par la crise.", example: "La déflation en est la première réponse, et elle aggrave la crise." },
  { id: "interventionnisme", term: "Interventionnisme", chapter: "crise", def: "L’État intervient dans l’économie : lois, dépenses, protection sociale, contrôle du crédit.", example: "New Deal, Front populaire." },
  { id: "protectionnisme", term: "Protectionnisme", chapter: "crise", def: "Barrières aux importations pour protéger le marché national. Le cours y ajoute ensuite des zones régionales.", example: "Contrôle des marchés extérieurs après 1929." },
  { id: "deflation", term: "Déflation", chapter: "crise", def: "Politique de baisse des prix et des salaires. Dans le cours, c’est la première réaction libérale, et elle aggrave la crise.", example: "Baisse des salaires → chute de la consommation." },
  { id: "keynes", term: "Keynésianisme", chapter: "crise", def: "Relance par la dépense publique et la protection sociale, d’après John Maynard Keynes. L’État dépense pour recréer de l’emploi.", example: "New Deal de Roosevelt." },
  { id: "etalon", term: "Étalon-or", chapter: "crise", def: "Système où la monnaie est liée à l’or. La crise le détruit, avec la production et le commerce : les trois piliers.", example: "Effondrement entre 1929 et 1933." },
  { id: "hoover", term: "Hooverville", chapter: "crise", def: "Bidonville de chômeurs aux États-Unis, surnommé d’après le président Hoover, jugé responsable de la misère.", example: "Symbole de la crise sociale américaine." },
  { id: "dust", term: "Dust Bowl", chapter: "crise", def: "Sécheresse et tempêtes de poussière dans les Grandes Plaines. Les fermiers, déjà ruinés par la chute des prix, partent.", example: "Exode rural massif au début des années 1930." },
  { id: "tva", term: "TVA", chapter: "crise", def: "Tennessee Valley Authority. Agence du premier New Deal : grands travaux, barrages, électrification, pour relancer l’emploi.", example: "1er New Deal, 1933-1934." },
  { id: "pwa", term: "PWA", chapter: "crise", def: "Public Works Administration. Grands travaux publics fédéraux du New Deal.", example: "Cité avec la TVA comme politique d’emploi." },
  { id: "ssa", term: "Social Security Act", chapter: "crise", def: "Loi américaine de 1935 qui instaure un système d’assurances sociales. Cœur du second New Deal.", example: "1935, dans le 2e New Deal (1935-1938)." },
  { id: "sfio", term: "SFIO", chapter: "crise", def: "Section française de l’Internationale ouvrière, le parti socialiste. Pilier du Front populaire, parti de Léon Blum.", example: "Victoire d’avril-mai 1936." },
  { id: "cgpf", term: "CGPF", chapter: "crise", def: "Confédération générale de la production française : l’organisation du patronat qui signe Matignon.", example: "En face de la CGT, 7-8 juin 1936." },
  { id: "cgt", term: "CGT", chapter: "crise", def: "Confédération générale du travail, le grand syndicat ouvrier signataire des accords Matignon.", example: "Liberté syndicale et conventions collectives." },
  { id: "etat-social", term: "État social", chapter: "crise", def: "État qui protège contre les risques sociaux (chômage, maladie, vieillesse) et encadre le travail. Le Front populaire en pose les bases en France.", example: "Congés payés, 40 heures, même si Blum tombe en 1937." },
  { id: "estado", term: "Estado Novo", chapter: "crise", def: "« État nouveau » : dictature nationaliste instaurée au Brésil par Getúlio Vargas en 1937, appuyée sur la propagande.", example: "Industrialisation planifiée, économie mixte, démocratie affaiblie." },
  { id: "mixte", term: "Économie mixte", chapter: "crise", def: "Économie où coexistent entreprises privées et entreprises liées à l’État.", example: "Brésil de Vargas : pétrole, minerais, industrie lourde." },
  { id: "autocentre", term: "Développement autocentré", chapter: "crise", def: "Croissance tournée vers le marché intérieur, pour moins dépendre des exportations.", example: "Réponse brésilienne à la chute de 50 % des exportations." },
  { id: "totalitarisme", term: "Totalitarisme", chapter: "regimes", def: "Selon Raymond Aron dans le cours : dictature qui prend toute la société, vie privée comprise, et réunit cinq traits (parti unique et chef, idéologie de l’homme nouveau, terreur, monopole des médias, dirigisme vers l’autarcie et la conquête).", example: "URSS stalinienne, Italie fasciste, Allemagne nazie." },
  { id: "parti", term: "Parti unique", chapter: "regimes", def: "Un seul parti est autorisé. Il se confond avec l’État.", example: "PCUS unique dès 1923, PNF en 1925, NSDAP en 1933." },
  { id: "culte", term: "Culte de la personnalité", chapter: "regimes", def: "Adoration organisée du chef, qui crée un lien direct avec la population, par-dessus les institutions.", example: "Vodj, Duce, Führer." },
  { id: "homme", term: "Homme nouveau", chapter: "regimes", def: "Type humain que l’idéologie prétend fabriquer, et qui justifie l’encadrement de toute la société.", example: "Travailleur soviétique, homme fort fasciste, Aryen nazi." },
  { id: "embrigadement", term: "Embrigadement", chapter: "regimes", def: "Encadrement obligatoire des corps et des esprits pour obtenir l’adhésion : jeunesse, loisirs, travail.", example: "Komsomol, Balilla, Jeunesses hitlériennes." },
  { id: "propagande", term: "Propagande", chapter: "regimes", def: "Discours, images et rites imposés pour faire aimer le régime et haïr ses ennemis. Elle suppose le monopole des médias.", example: "Stakhanovisme, affiche de la famille aryenne, JO de 1936." },
  { id: "censure", term: "Censure", chapter: "regimes", def: "Interdiction de ce qui contredit le régime : presse, livres, images.", example: "Autodafés nazis, censure italienne." },
  { id: "dirigisme", term: "Dirigisme", chapter: "regimes", def: "L’État dirige l’économie au lieu de laisser le marché. Ici, ce n’est pas pour le bien-être : c’est pour l’idéologie.", example: "Planification soviétique, guerre du blé, industrie de guerre allemande." },
  { id: "autarcie", term: "Autarcie", chapter: "regimes", def: "Produire soi-même ce qu’on consomme, se passer de l’extérieur. Le cours dit qu’elle pousse à élargir le territoire.", example: "Guerre du blé, espace vital." },
  { id: "espace", term: "Espace vital", chapter: "regimes", def: "Lebensraum : territoire que le nazisme prétend devoir conquérir, surtout à l’Est, pour la « race » aryenne.", example: "Justifie la militarisation puis l’agression." },
  { id: "panger", term: "Pangermanisme", chapter: "monde", def: "Projet de réunir les populations germanophones dans un même Reich.", example: "Anschluss, puis revendication des Sudètes." },
  { id: "kolkhoze", term: "Kolkhoze", chapter: "regimes", def: "Exploitation agricole collective soviétique. Les terres des paysans y sont mises en commun.", example: "Collectivisation à partir de 1929." },
  { id: "kolkhozien", term: "Kolkhozien", chapter: "regimes", def: "Paysan qui travaille dans un kolkhoze. Avec l’ouvrier, c’est le modèle d’homme nouveau soviétique.", example: "À distinguer du koulak, qui est la cible." },
  { id: "koulak", term: "Koulak", chapter: "regimes", def: "Paysan aisé, désigné comme ennemi de classe et éliminé pendant la collectivisation (dékoulakisation).", example: "Début de la marche forcée de 1929." },
  { id: "goulag", term: "Goulag", chapter: "regimes", def: "Système des camps de travail soviétiques. Le NKVD y envoie les « ennemis ».", example: "Grande Terreur, 1936-1938." },
  { id: "guepeou", term: "Guépéou", chapter: "regimes", def: "Police politique soviétique de 1922 à 1934, ensuite intégrée au NKVD.", example: "Ne pas la confondre avec la Gestapo ni l’OVRA." },
  { id: "nkvd", term: "NKVD", chapter: "regimes", def: "Commissariat du peuple aux Affaires intérieures. À partir de 1934, il absorbe la police politique et organise la terreur.", example: "Goulag, Grande Terreur." },
  { id: "pcus", term: "PCUS", chapter: "regimes", def: "Parti communiste de l’Union soviétique, créé en 1918, parti unique à partir de 1923.", example: "Staline en prend la tête en 1928." },
  { id: "pnf", term: "Parti national fasciste", chapter: "regimes", def: "Parti de Mussolini, créé en 1921, unique en 1925.", example: "Lois fascistissimes 1925-1926." },
  { id: "nsdap", term: "NSDAP", chapter: "regimes", def: "Parti national-socialiste des travailleurs allemands, le parti nazi, créé en 1920, unique en 1933.", example: "Premier parti au Reichstag en juillet 1932." },
  { id: "sa", term: "SA", chapter: "regimes", def: "Sturmabteilung, sections d’assaut, chemises brunes. Milice créée par Hitler à Munich en 1921, service d’ordre du parti. Rôle réduit après 1934.", example: "Victimes de la Nuit des Longs Couteaux." },
  { id: "ss", term: "SS", chapter: "regimes", def: "Schutzstaffel, escadron de protection. C’est cette troupe qui assassine les chefs SA en juin 1934, sur ordre d’Hitler.", example: "À ne pas confondre avec la Gestapo, qui est la police." },
  { id: "gestapo", term: "Gestapo", chapter: "regimes", def: "Police politique nazie, fondée en 1933 par Göring, développée par Himmler. Elle traque les opposants, réels ou supposés.", example: "Arrestation, assassinat ou camp." },
  { id: "ovra", term: "OVRA", chapter: "regimes", def: "Police politique fasciste créée en 1927. Onze inspectorats, indicateurs, répression de la presse et des opposants, camps de travail. Supprimée en 1945.", example: "Vient après les squadristes, ne les remplace pas entièrement." },
  { id: "squad", term: "Squadristes", chapter: "regimes", def: "Chemises noires : milice paramilitaire fasciste. Elles portent Mussolini au pouvoir en 1922 et terrorisent les campagnes.", example: "Violence du parti, avant la police officielle." },
  { id: "komsomol", term: "Komsomol", chapter: "regimes", def: "Organisation de la jeunesse communiste. Formation marxiste-léniniste, travail, loisirs, alphabétisation.", example: "Outil d’embrigadement soviétique." },
  { id: "balilla", term: "Balilla", chapter: "regimes", def: "Jeunesses mussoliniennes (Opera Nazionale Balilla). Culte du Duce, discipline, préparation militaire.", example: "L’équivalent italien des Jeunesses hitlériennes." },
  { id: "dopolavoro", term: "Dopolavoro", chapter: "regimes", def: "Opera Nazionale Dopolavoro : organisation d’État pour les loisirs des Italiens (sport, théâtre, jeux). Le cours précise que le roi et le pape en limitent la portée.", example: "Preuve que l’embrigadement italien est incomplet." },
  { id: "stakha", term: "Stakhanovisme", chapter: "regimes", def: "Propagande du travailleur modèle, du nom d’Alekseï Stakhanov. On célèbre le dépassement des normes de production.", example: "Versant soviétique du culte de l’effort." },
  { id: "jo", term: "JO de Berlin", chapter: "regimes", def: "Jeux olympiques de 1936, vitrine du régime nazi. Le cours retient que l’effet est limité par les victoires de l’athlète américain Jesse Owens.", example: "Propagande puissante, mais pas toute-puissante." },
  { id: "fascistissimes", term: "Lois fascistissimes", chapter: "regimes", def: "Lois de 1925-1926 qui installent en Italie un État nationaliste et autoritaire, et rendent le parti fasciste unique.", example: "À citer avec les lois de Nuremberg et la collectivisation." },
  { id: "nuremberg", term: "Lois de Nuremberg", chapter: "regimes", def: "15 septembre 1935 : les Juifs perdent la citoyenneté allemande. L’antisémitisme devient la loi de l’État.", example: "À ne pas confondre avec la Nuit de Cristal (1938)." },
  { id: "cristal", term: "Nuit de Cristal", chapter: "regimes", def: "Pogrom des 9 et 10 novembre 1938 : synagogues, magasins et Juifs sont attaqués au grand jour. Environ 30 000 hommes sont envoyés en camp.", example: "La terreur n’est plus seulement policière, elle est de masse." },
  { id: "longs", term: "Nuit des Longs Couteaux", chapter: "regimes", def: "29-30 juin 1934 : les SS assassinent environ 85 chefs SA sur ordre d’Hitler. Purge à l’intérieur du parti nazi.", example: "La violence sert aussi à unifier le parti." },
  { id: "graziani", term: "Massacre de Graziani", chapter: "regimes", def: "Après l’attentat du 19 février 1937 contre le vice-roi Graziani à Addis-Abeba, les troupes italiennes massacrent des civils éthiopiens. Le cours en fait le visage colonial de la terreur fasciste.", example: "À citer avec la Grande Terreur et la Nuit de Cristal." },
  { id: "sdn", term: "SDN", chapter: "monde", def: "Société des Nations, organisation née après 1918 pour garantir la paix. Le cours la juge discréditée : inutile en Rhénanie, sans sanction efficace contre l’Italie en Éthiopie.", example: "Symbole de l’impuissance des démocraties." },
  { id: "stresa", term: "Front de Stresa", chapter: "monde", def: "Entente de 1935 entre la France, l’Italie et la Grande-Bretagne contre la menace hitlérienne. Elle meurt quand l’Italie rejoint l’Allemagne.", example: "Ne pas le confondre avec l’axe Rome-Berlin." },
  { id: "axe", term: "Axe Rome-Berlin", chapter: "monde", def: "Rapprochement italo-allemand d’octobre 1936, protocole d’entente antibolchevique.", example: "Étape vers le pacte d’acier de 1939." },
  { id: "komintern", term: "Pacte anti-Komintern", chapter: "monde", def: "Alliance contre l’Internationale communiste. Allemagne-Japon le 25 novembre 1936, Italie le 6 novembre 1937, Espagne en 1938.", example: "Montre que les régimes sont alors antagonistes de l’URSS." },
  { id: "acier", term: "Pacte d’acier", chapter: "monde", def: "22 mai 1939 : alliance militaire automatique et offensive entre l’Allemagne et l’Italie.", example: "Ce n’est pas le pacte avec Staline." },
  { id: "pacte-gs", term: "Pacte germano-soviétique", chapter: "monde", def: "23 août 1939, Ribbentrop et Molotov : non-agression de dix ans, plus des clauses secrètes sur la Pologne, la Finlande, les pays baltes et la Bessarabie.", example: "Les ennemis idéologiques deviennent alliés le temps d’ouvrir la guerre." },
  { id: "anschluss", term: "Anschluss", chapter: "monde", def: "Rattachement de l’Autriche au Reich. La Wehrmacht entre le 12 mars 1938, l’annexion est proclamée le 13. L’Autriche est rebaptisée Ostmark.", example: "Plébiscite truqué : 99,75 %." },
  { id: "sudetes", term: "Sudètes", chapter: "monde", def: "Région germanophone de Tchécoslovaquie revendiquée par Hitler le 12 septembre 1938 et cédée à Munich.", example: "Le pays est démembré dès le lendemain de la conférence." },
  { id: "munich", term: "Conférence de Munich", chapter: "monde", def: "Septembre 1938. Hitler, Mussolini, Daladier et Chamberlain. Les démocraties cèdent. L’URSS est absente. Illusion de paix.", example: "Déclaration anglo-allemande de non-agression dans la foulée." },
  { id: "attentisme", term: "Attentisme", chapter: "monde", def: "Politique d’attente et de concessions pour éviter la guerre. Le cours l’oppose à une fermeté que les démocraties n’assument pas.", example: "De la Rhénanie à Munich." },
  { id: "rhenanie", term: "Rhénanie", chapter: "monde", def: "Zone allemande démilitarisée par Versailles. Hitler l’occupe le 7 mars 1936, en violant le traité, sans réaction militaire française.", example: "Coup de poker réussi." },
  { id: "ostmark", term: "Ostmark", chapter: "monde", def: "Nom nazi de l’Autriche après l’Anschluss : elle n’est plus un État, elle devient une marche de l’Est du Reich.", example: "À placer juste après le 13 mars 1938." },
  { id: "problematique", term: "Problématique", chapter: "crise", def: "Question une, qui définit les mots du sujet, fixe le temps et l’espace, et met au jour une tension. Elle annonce le plan sans le recopier.", example: "La problématique du chapitre 1 tient en une question sur les équilibres, les modèles et l’État." },
];

export const COMPARE: CompareRow[] = [
  {
    id: "ideo",
    label: "Idéologie et homme nouveau",
    it: "Fascisme : État au centre, nation, parallèle avec Rome. Homme nouveau fort, discipliné, au service de la patrie.",
    de: "Nazisme (Mein Kampf) : nation, race, antisémitisme, anticommunisme, pangermanisme, espace vital. Homme nouveau : l’Aryen.",
    su: "Marxisme-léninisme : communisme internationaliste, dictature du prolétariat. Homme nouveau : le travailleur, ouvrier et kolkhozien.",
  },
  {
    id: "lois",
    label: "Grandes lois",
    it: "Lois fascistissimes (1925-1926). Lois antisémites de 1938 : tournant vers l’Allemagne.",
    de: "Lois de Nuremberg, 15 septembre 1935 : les Juifs perdent la citoyenneté. Loi de 1938 : ils sont chassés de l’économie.",
    su: "Collectivisation et planification dès 1929.",
  },
  {
    id: "parti",
    label: "Parti unique",
    it: "Parti national fasciste, créé en 1921, unique en 1925.",
    de: "NSDAP, créé en 1920, unique en 1933.",
    su: "PCUS, créé en 1918, unique dès 1923.",
  },
  {
    id: "pouvoir",
    label: "Arrivée au pouvoir",
    it: "Marche sur Rome, 1922, 26 000 fascistes. Le roi nomme Mussolini président du Conseil.",
    de: "Juillet 1932 : premier parti. 30 janvier 1933 : chancelier. 2 août 1934 : mort d’Hindenburg, Hitler seul.",
    su: "1917 : révolution. 1922 : création de l’URSS. 1927 : purge des trotskystes. 1928 : Staline à la tête du parti et de l’État.",
  },
  {
    id: "chef",
    label: "Le chef",
    it: "Mussolini (1883-1945), le Duce, le guide. Il doit encore compter avec le roi.",
    de: "Hitler (1889-1945), le Führer. Culte du chef de guerre.",
    su: "Staline (1879-1953), le Vodj, petit père des peuples. Image rassurante et entourage craint.",
  },
  {
    id: "eco",
    label: "Économie",
    it: "Grands chantiers, assèchement des marais, guerre du blé : autarcie par le marché intérieur.",
    de: "Militarisation (Ruhr), exclusion des Juifs (1938), préparation de la conquête.",
    su: "Kolkhozes, fin des koulaks, industrie nationalisée, marche forcée de 1929.",
  },
  {
    id: "prop",
    label: "Propagande et censure",
    it: "Culte du Duce, grandeur de l’État, image du père de famille fort. Censure.",
    de: "Mythe aryen, aigle, parti protecteur. Censure de la presse, autodafés, affiche de la famille aryenne.",
    su: "Stakhanovisme : le meilleur ouvrier ou paysan. Culte du Vodj.",
  },
  {
    id: "jeun",
    label: "Jeunesse et loisirs",
    it: "Balilla : discipline et service militaire. Dopolavoro : loisirs d’État, limités par le roi et le pape.",
    de: "Jeunesses hitlériennes : sport, peu d’esprit critique. JO de Berlin, 1936.",
    su: "Komsomol : marxisme-léninisme, travail, loisirs, alphabétisation.",
  },
  {
    id: "pol",
    label: "Violence d’État",
    it: "Squadristes dès 1922. OVRA en 1927. Massacre de Graziani, février 1937.",
    de: "SA (1921), Gestapo (1933), SS. Nuit des Longs Couteaux (1934), Nuit de Cristal (1938).",
    su: "Guépéou puis NKVD. Purge de 1927. Famine ukrainienne 1932-1933. Grande Terreur 1936-1938. Goulag.",
  },
];

export const EVENTS: TimelineEvent[] = [
  { id: "e1917", sort: 1917, when: "1917", title: "Révolution bolchevique", text: "Les bolcheviks prennent le pouvoir en Russie. Point de départ du régime qui devient l’URSS.", tone: "terror" },
  { id: "e1921", sort: 1921.1, when: "1921", title: "SA et parti fasciste", text: "Hitler crée les SA à Munich. Le Parti national fasciste est fondé la même année.", tone: "terror" },
  { id: "e1922", sort: 1922.1, when: "1922", title: "Marche sur Rome et naissance de l’URSS", text: "26 000 fascistes marchent sur Rome : Mussolini chef du gouvernement. L’Union soviétique est créée. Le Guépéou aussi.", tone: "terror" },
  { id: "e1925", sort: 1925, when: "1925-1926", title: "Lois fascistissimes", text: "Le parti fasciste devient unique. L’État italien devient nationaliste et autoritaire.", tone: "terror" },
  { id: "e1926", sort: 1926, when: "1926-1929", title: "La bulle", text: "Les cours américains sont multipliés par six. On achète des actions à crédit.", tone: "crisis" },
  { id: "e1927", sort: 1927, when: "1927", title: "OVRA et trotskystes", text: "Mussolini crée l’OVRA. Staline évince les trotskystes et refuse tout compromis avec Trotsky.", tone: "terror" },
  { id: "e1928", sort: 1928, when: "1928", title: "Staline seul", text: "Il prend la tête du parti et de l’URSS.", tone: "terror" },
  { id: "e1929", sort: 1929.8, when: "24 et 29 oct. 1929", title: "Jeudi noir, mardi noir", text: "12 millions puis 16 millions d’actions. Le krach ouvre la crise. La collectivisation soviétique commence la même année.", tone: "crisis" },
  { id: "e1932", sort: 1932.11, when: "1932", title: "Roosevelt et le NSDAP", text: "Roosevelt est élu. En juillet, le NSDAP est le premier parti allemand. Pacte de non-agression franco-soviétique.", tone: "demo" },
  { id: "e1933", sort: 1933.08, when: "30 janvier 1933", title: "Hitler chancelier", text: "Hindenburg le nomme. La Gestapo est créée dans l’année. Le New Deal d’urgence commence. 25 % des Américains sont sans emploi.", tone: "terror" },
  { id: "e1934f", sort: 1934.15, when: "6 février 1934", title: "Émeutes à Paris", text: "La crise politique française éclate dans la rue. La République paraît fragile.", tone: "crisis" },
  { id: "e1934", sort: 1934.5, when: "29-30 juin 1934", title: "Nuit des Longs Couteaux", text: "Les SS tuent environ 85 chefs SA. Le 2 août, Hindenburg meurt : Hitler cumule les pouvoirs.", tone: "terror" },
  { id: "e1935", sort: 1935.7, when: "1935", title: "Nuremberg, Stresa, Social Security", text: "15 septembre : lois de Nuremberg. Front de Stresa. Social Security Act. Début du second New Deal. L’Italie attaque l’Éthiopie.", tone: "geo" },
  { id: "e1936r", sort: 1936.25, when: "7 mars 1936", title: "Rhénanie", text: "Hitler remilitarise la rive gauche. La France proteste sans bouger l’armée.", tone: "geo" },
  { id: "e1936m", sort: 1936.45, when: "juin 1936", title: "Matignon", text: "7-8 juin : salaires +7 à 15 %. Puis 40 heures et congés payés. Blum gouverne depuis avril-mai.", tone: "demo" },
  { id: "e1936a", sort: 1936.8, when: "automne 1936", title: "Axe et anti-Komintern", text: "Octobre : axe Rome-Berlin. 25 novembre : pacte anti-Komintern Allemagne-Japon. Guerre d’Espagne. JO de Berlin.", tone: "geo" },
  { id: "e1937", sort: 1937.2, when: "1937", title: "Vargas, Blum, Graziani", text: "Estado Novo au Brésil. Blum démissionne. 19 février : massacre de Graziani en Éthiopie. 6 novembre : l’Italie rejoint l’anti-Komintern.", tone: "terror" },
  { id: "e1938a", sort: 1938.25, when: "mars 1938", title: "Anschluss", text: "12 mars : entrée en Autriche. 13 mars : annexion. L’Autriche devient l’Ostmark. Plébiscite à 99,75 %.", tone: "geo" },
  { id: "e1938m", sort: 1938.7, when: "sept. 1938", title: "Munich", text: "Hitler, Mussolini, Daladier, Chamberlain. Les Sudètes sont cédés. L’URSS est absente.", tone: "geo" },
  { id: "e1938c", sort: 1938.85, when: "9-10 nov. 1938", title: "Nuit de Cristal", text: "Pogrom antijuif. La même année, les Juifs sont chassés de l’économie allemande.", tone: "terror" },
  { id: "e1939c", sort: 1939.25, when: "mars-mai 1939", title: "Tchécoslovaquie, Albanie, acier", text: "Mars : fin de la Tchécoslovaquie. Avril : l’Italie envahit l’Albanie. 22 mai : pacte d’acier.", tone: "geo" },
  { id: "e1939p", sort: 1939.7, when: "23 août 1939", title: "Pacte germano-soviétique", text: "Ribbentrop et Molotov. Non-agression et partage secret de l’Europe de l’Est.", tone: "geo" },
  { id: "e1939g", sort: 1939.9, when: "1er et 3 sept. 1939", title: "La guerre", text: "1er septembre : invasion de la Pologne. 3 septembre : la France et le Royaume-Uni déclarent la guerre.", tone: "geo" },
  { id: "e1940", sort: 1940.5, when: "juin 1940", title: "L’Italie entre en guerre", text: "Après des négociations inutiles, Mussolini ne s’engage qu’une fois la France déjà vaincue en vue.", tone: "geo" },
];

export const TRAPS: Trap[] = [
  { id: "t1", wrong: "Confondre jeudi noir et mardi noir.", right: "24 octobre = jeudi noir = 12 millions d’actions. 29 octobre = mardi noir = 16 millions." },
  { id: "t2", wrong: "Mettre le New Deal tout entier en 1933.", right: "1er New Deal, 1933-1934 : urgence bancaire et grands travaux. 2e New Deal, 1935-1938 : salaires, syndicats, Social Security Act (1935)." },
  { id: "t3", wrong: "Croire que la déflation est la solution keynésienne.", right: "Déflation = réaction libérale = la crise empire. Keynésianisme = relance par la dépense = New Deal et Front populaire." },
  { id: "t4", wrong: "Mélanger SA, SS et Gestapo.", right: "SA : milice de 1921, purgée en 1934. SS : ils font la purge. Gestapo : police politique, fondée en 1933 par Göring." },
  { id: "t5", wrong: "Mélanger kolkhoze, kolkhozien et koulak.", right: "Kolkhoze = ferme collective. Kolkhozien = celui qui y travaille. Koulak = paysan aisé visé par la répression." },
  { id: "t6", wrong: "Confondre les trois pactes de la fin des années 1930.", right: "Axe Rome-Berlin : octobre 1936. Pacte d’acier Allemagne-Italie : 22 mai 1939. Pacte germano-soviétique : 23 août 1939." },
  { id: "t7", wrong: "Faire de Stresa une alliance avec Hitler.", right: "Stresa, 1935 : France, Italie, Royaume-Uni contre la menace hitlérienne. L’axe, c’est l’inverse." },
  { id: "t8", wrong: "Dater la Nuit de Cristal en 1934 ou les lois de Nuremberg en 1938.", right: "Nuremberg = 15 septembre 1935 (la loi). Nuit de Cristal = 9-10 novembre 1938 (le pogrom). Longs Couteaux = 29-30 juin 1934 (la purge)." },
  { id: "t9", wrong: "Oublier que Mussolini n’est pas seul.", right: "Il a l’exécutif depuis 1922, mais le roi reste là. Le pape limite aussi le Dopolavoro. L’enracinement est incomplet." },
  { id: "t10", wrong: "Placer la famine ukrainienne pendant la Grande Terreur.", right: "Famine organisée : 1932-1933. Grande Terreur : 1936-1938. Deux moments, deux paragraphes." },
];

export const STORIES: Story[] = [
  {
    id: "s-krach",
    date: "24 et 29 octobre 1929",
    title: "Les deux jours noirs de Wall Street",
    tone: "crisis",
    place: "New York",
    prompts: ["Quel jour, quel chiffre ?", "Que font les banques juste après ?", "Pourquoi le monde entier est touché ?"],
    beats: [
      "Depuis 1926, les cours ont été multipliés par six. Des ménages achètent des actions à crédit. Six grandes banques ont prêté 24 milliards de dollars à la spéculation.",
      "Le jeudi 24 octobre, 12 millions d’actions sont offertes et personne ne les achète. Le mardi 29, 16 millions de plus. Les cours s’effondrent.",
      "La confiance disparaît. Les banques ne prêtent plus, puis font faillite. Le crédit se ferme, l’investissement s’arrête.",
      "Ce n’est encore « que » financier. La dépression économique vient dans les mois suivants, parce que la demande et l’emploi s’écroulent ensemble.",
    ],
    copie: "Ouvre un paragraphe de causes ou de déroulement. Enchaîne tout de suite avec le chiffre de 1933 (PIB −30 %, chômage 25 %) pour montrer que le krach n’est que le détonateur.",
  },
  {
    id: "s-hoover",
    date: "1930-1933",
    title: "Hoovervilles et Dust Bowl",
    tone: "crisis",
    place: "États-Unis",
    prompts: ["Quel surnom pour les bidonvilles ?", "Quel pourcentage de chômage ?", "Que se passe-t-il dans les campagnes ?"],
    beats: [
      "En 1933, un Américain sur quatre est sans emploi : environ 13 millions de personnes. Les salaires ont baissé d’environ 40 %.",
      "Des familles s’installent dans des bidonvilles qu’on appelle Hoovervilles, du nom du président Hoover. À New York, en 1930, les chômeurs manifestent.",
      "Les prix agricoles s’effondrent. Le Dust Bowl — sécheresse et tempêtes de poussière — achève les fermiers. L’exode rural est massif.",
      "Moins de salaires, moins d’achats, encore plus de faillites : c’est le cercle de la dépression, pas un simple accident boursier.",
    ],
    copie: "Sert la crise sociale. Ajoute les marches de la faim britanniques de 1932 pour montrer que la misère n’est pas seulement américaine.",
  },
  {
    id: "s-6fev",
    date: "6 février 1934",
    title: "La rue contre la République",
    tone: "crisis",
    place: "Paris",
    prompts: ["Quelle date ?", "Quel climat politique ?", "Quel lien avec 1936 ?"],
    beats: [
      "La crise arrive en France au début des années 1930 : chômage, populisme, gouvernements instables.",
      "Le 6 février 1934, des ligues manifestent violemment à Paris. La République semble incapable de tenir la rue.",
      "Cet épisode nourrit la peur, à gauche, d’un basculement autoritaire, et prépare l’union du Front populaire.",
      "Avril-mai 1936 : SFIO, radicaux et communistes gagnent. Blum gouverne. Mais le patronat n’a pas désarmé : il démissionne en 1937.",
    ],
    copie: "Transition parfaite entre la crise sociale et la réponse politique française. Ne commence pas Matignon sans avoir posé le 6 février.",
  },
  {
    id: "s-couteaux",
    date: "29-30 juin 1934",
    title: "La Nuit des Longs Couteaux",
    tone: "terror",
    place: "Allemagne",
    prompts: ["Qui tue qui ?", "Quel chiffre le cours retient-il ?", "Pourquoi Hitler frappe-t-il son propre parti ?"],
    beats: [
      "Les SA, chemises brunes, ont porté Hitler depuis 1921. Une partie de leurs chefs conteste désormais sa ligne.",
      "Dans la nuit du 29 au 30 juin 1934, les SS assassinent environ 85 SA, chefs compris, sur ordre d’Hitler.",
      "Le parti se purge lui-même. La violence n’est pas réservée aux opposants extérieurs : elle est un mode de gouvernement.",
      "Le 2 août 1934, Hindenburg meurt. Plus de président au-dessus du chancelier. Hitler concentre le pouvoir.",
    ],
    copie: "Exemple roi de la « purge ». À placer dans la partie sur la terreur, à côté de la purge des trotskystes en 1927, pour comparer.",
  },
  {
    id: "s-famine",
    date: "1932-1933",
    title: "La famine organisée en Ukraine",
    tone: "terror",
    place: "Ukraine soviétique",
    prompts: ["Quel lien avec la collectivisation ?", "Qui est visé, au-delà des opposants ?", "Quelle définition d’Aron cela illustre ?"],
    beats: [
      "Depuis 1929, l’État collectivise les terres, brise les koulaks et verse les paysans dans les kolkhozes. Les réquisitions de grain sont massives.",
      "En 1932-1933, une famine ravage l’Ukraine. Le cours la qualifie d’organisée : ce n’est pas un simple accident climatique.",
      "Des millions de paysans meurent. La terreur frappe une société entière, pas un complot.",
      "C’est le sens de la formule d’Aron : la terreur ne se limite pas aux opposants du régime.",
    ],
    copie: "À ne pas fondre avec la Grande Terreur de 1936-1938. Deux dates, deux idées : la famine montre la guerre contre la paysannerie ; la Grande Terreur, la paranoïa au sommet du parti.",
  },
  {
    id: "s-terreur",
    date: "1936-1938",
    title: "La Grande Terreur",
    tone: "terror",
    place: "URSS",
    prompts: ["Quel déclencheur en 1934 ?", "Quel organisme ?", "Où envoie-t-on les « ennemis » ?"],
    beats: [
      "L’assassinat de Kirov, en décembre 1934, sert de déclencheur politique. Le pic de la terreur est 1936-1938.",
      "Le NKVD, qui a absorbé le Guépéou, arrête par vagues : communistes, cadres, anonymes. La peur d’un complot étranger justifie tout.",
      "Les « ennemis » partent au goulag, ou sont exécutés. Le parti lui-même est décimé.",
      "Comme la Nuit des Longs Couteaux, c’est une violence retournée vers l’intérieur du camp au pouvoir.",
    ],
    copie: "Montre que le totalitarisme stalinien est de « haute intensité ». Termine sur l’enracinement incomplet : révoltes, baisse des rendements, culture des grands-parents.",
  },
  {
    id: "s-cristal",
    date: "9-10 novembre 1938",
    title: "La Nuit de Cristal",
    tone: "terror",
    place: "Allemagne",
    prompts: ["Quelle date exacte ?", "En quoi ce n’est plus seulement une loi ?", "Quel lien avec 1935 ?"],
    beats: [
      "Depuis les lois de Nuremberg du 15 septembre 1935, les Juifs ne sont plus des citoyens. En 1938, une loi les chasse de l’économie.",
      "Dans la nuit du 9 au 10 novembre 1938, synagogues et magasins sont détruits, des Juifs sont agressés, environ 30 000 hommes sont déportés en camp.",
      "Le nom « Nuit de Cristal » vient des vitrines brisées. La violence est publique, de masse, assumée.",
      "La propagande a préparé l’événement : l’ennemi est désigné, la rue applique ce que la loi a commencé.",
    ],
    copie: "Chaîne à connaître par cœur : 1935 la loi, 1938 l’exclusion économique, 9-10 novembre 1938 le pogrom. Cela prouve le monopole de la violence et l’antisémitisme d’État.",
  },
  {
    id: "s-graziani",
    date: "19 février 1937",
    title: "Le massacre de Graziani",
    tone: "terror",
    place: "Addis-Abeba, Éthiopie",
    prompts: ["Après quelle conquête ?", "Quel attentat ?", "Pourquoi le cours le met avec la terreur européenne ?"],
    beats: [
      "L’Italie conquiert l’Éthiopie en 1935-1936. La SDN la désigne agresseur sans sanction efficace : Rome en sort enhardie.",
      "Le 19 février 1937, un attentat vise le vice-roi Rodolfo Graziani à Addis-Abeba.",
      "Les représailles italiennes tuent des milliers de civils dans les jours qui suivent. Le cours parle d’une politique d’anéantissement.",
      "Le fascisme n’est donc pas « plus doux ». Sa terreur s’exerce aussi dans l’empire, pas seulement dans la péninsule.",
    ],
    copie: "Sert deux idées : la violence fasciste, et l’impunité internationale. Enchaîne avec l’Albanie en avril 1939 si tu es dans la partie géopolitique.",
  },
  {
    id: "s-anschluss",
    date: "12-13 mars 1938",
    title: "L’Anschluss",
    tone: "geo",
    place: "Autriche",
    prompts: ["Quelle différence entre le 12 et le 13 mars ?", "Quel pourcentage ?", "Quel nouveau nom ?"],
    beats: [
      "Le pangermanisme veut réunir les germanophones. L’Autriche est la première cible après la Rhénanie.",
      "Le 12 mars 1938, la Wehrmacht entre. Le 13 mars, l’Anschluss est proclamé.",
      "En avril, un plébiscite donne 99,75 % pour l’annexion. Le chiffre dit la contrainte plus que l’adhésion.",
      "L’Autriche disparaît comme État et devient l’Ostmark, une « marche de l’Est » du Reich.",
    ],
    copie: "Étape 1 de la marche à la guerre, avant les Sudètes. Souligne qu’aucune démocratie n’intervient : l’attentisme est déjà en place.",
  },
  {
    id: "s-munich",
    date: "septembre 1938 – septembre 1939",
    title: "De Munich à la Pologne",
    tone: "geo",
    place: "Europe",
    prompts: ["Qui est autour de la table ?", "Qui n’y est pas ?", "Quelle date ouvre vraiment la guerre ?"],
    beats: [
      "Le 12 septembre 1938, à Nuremberg, Hitler revendique les Sudètes. À Munich, il obtient gain de cause face à Daladier et Chamberlain, Mussolini à ses côtés. Staline n’est pas invité.",
      "Paris et Londres croient avoir acheté la paix. Le Royaume-Uni signe même une déclaration de non-agression avec l’Allemagne. L’URSS se sent trahie.",
      "Mars 1939 : la Tchécoslovaquie est dépecée pour de bon. Hitler se croit intouchable. Le 23 août, il s’entend avec Staline : pacte et partage secret.",
      "1er septembre 1939, la Wehrmacht entre en Pologne. Le 3, la France et le Royaume-Uni déclarent la guerre. L’Italie attend juin 1940.",
    ],
    copie: "Conclusion toute faite : la paix à tout prix discrédite les démocraties et laisse les régimes totalitaires, hier ennemis, décider ensemble de l’ouverture de la guerre.",
  },
];

export const SUBJECTS: RqpSubject[] = [
  {
    id: "s1",
    tag: "Chapitre 1",
    question: "La crise de 1929 est une crise économique et sociale mondiale.",
    define: ["crise économique", "crise sociale", "krach", "dépression"],
    intro:
      "Les années 1920 ont donné l’illusion d’un retour à la prospérité : on consomme de nouveau, on veut oublier la guerre, le libéralisme et le libre-échange semblent triompher. Pourtant l’économie américaine repose sur une surproduction, une bulle de crédit et des banques peu surveillées, tandis que l’Europe et l’Amérique latine dépendent des États-Unis. Le krach de Wall Street, les 24 et 29 octobre 1929, transforme ces fragilités en effondrement. Dans quelle mesure la crise ouverte en 1929 est-elle à la fois économique, sociale et mondiale, au point de remettre en cause l’ordre libéral hérité des années 1920 ?",
    parts: [
      {
        title: "I. Des fragilités américaines qui exposent déjà le monde",
        subs: [
          {
            title: "A. Une surproduction agricole et industrielle",
            details: [
              "Agriculture mécanisée et fermiers surendettés ; industrie de masse (automobile, électroménager, alimentaire) qui produit au-delà de la demande.",
              "Le marché intérieur ne peut plus absorber : la crise de débouchés précède le krach.",
            ],
          },
          {
            title: "B. Une bulle spéculative et un système bancaire fragile",
            details: [
              "Entre 1926 et 1929, les cours sont multipliés par six, sans lien avec la valeur réelle. Achat d’actions à crédit.",
              "Crédit à court terme peu contrôlé : six grandes banques ont prêté 24 milliards de dollars à la spéculation.",
            ],
          },
          {
            title: "C. Une dépendance mondiale envers les États-Unis",
            details: [
              "Les États-Unis sont les créanciers de l’Europe et les grands acheteurs des matières premières latino-américaines.",
              "Un choc né à Wall Street ne peut donc pas rester américain.",
            ],
          },
        ],
      },
      {
        title: "II. Du krach boursier à la dépression économique",
        subs: [
          {
            title: "A. Jeudi noir et mardi noir",
            details: [
              "24 octobre 1929 : 12 millions d’actions sans acheteur. 29 octobre : 16 millions supplémentaires. Les cours s’effondrent, la confiance aussi.",
            ],
          },
          {
            title: "B. Une crise financière : le crédit se ferme",
            details: [
              "Les banques cessent de prêter puis font faillite. Investissements en chute, faillites en chaîne.",
            ],
          },
          {
            title: "C. Les chiffres de la dépression, 1929-1933",
            details: [
              "PIB américain −30 %, production industrielle −45 %, exportations mondiales −25 %.",
              "En 1933, 25 % des Américains sont sans emploi (environ 13 millions). Les salaires baissent d’environ 40 % : le cercle vicieux est installé.",
            ],
          },
        ],
      },
      {
        title: "III. Une crise sociale mondiale qui brise l’ordre libéral",
        subs: [
          {
            title: "A. La misère au quotidien",
            details: [
              "Hoovervilles, manifestations de chômeurs à New York en 1930, marches de la faim au Royaume-Uni en 1932, Dust Bowl et exode rural.",
            ],
          },
          {
            title: "B. Un choc sur trois continents",
            details: [
              "Amérique latine, Europe et Asie : paupérisation, troubles, contestations. Les exportations latino-américaines chutent de 50 % entre 1929 et 1932.",
            ],
          },
          {
            title: "C. Trois piliers détruits",
            details: [
              "Production, commerce international, étalon-or. Le libéralisme est désavoué, l’État devra intervenir : New Deal, Front populaire, Estado Novo.",
            ],
          },
        ],
      },
    ],
    conclusion:
      "La crise de 1929 n’est donc ni un simple krach ni une affaire américaine. Partie d’une bulle et d’une surproduction, elle devient dépression, puis crise sociale mondiale, et elle emporte les trois piliers de l’économie libérale. Reste alors la question politique : les États qui tentent de répondre, par la relance ou par l’autorité, en sortiront transformés — jusqu’à faire de cette crise une des matrices des régimes autoritaires.",
  },
  {
    id: "s2",
    tag: "Chapitre 1",
    question: "Les réactions des États face à la crise économique et sociale.",
    define: ["interventionnisme", "déflation", "keynésianisme", "État social"],
    intro:
      "Après le krach d’octobre 1929, la dépression détruit l’emploi, les salaires et le commerce. Le laissez-faire, doctrine des années 1920, ne suffit plus : chaque État cherche une sortie, et presque partout l’État prend une place qu’il n’avait pas. Mais toutes les réponses ne se valent pas. Comment les États réagissent-ils à la crise, et pourquoi l’intervention, qu’elle soit démocratique ou autoritaire, s’impose-t-elle sans jamais effacer complètement la dépression ?",
    parts: [
      {
        title: "I. L’Amérique latine : la crise fait tomber les libéraux",
        subs: [
          {
            title: "A. Un modèle d’exportation qui s’effondre",
            details: [
              "Entre 1929 et 1932, la valeur des exportations chute de 50 %. L’activité se contracte, le chômage explose.",
            ],
          },
          {
            title: "B. De la rue au changement de régime",
            details: [
              "Manifestations, grèves, chute de plusieurs régimes libéraux, souvent remplacés par des pouvoirs autoritaires.",
            ],
          },
          {
            title: "C. Le Brésil de Vargas, laboratoire autoritaire",
            details: [
              "1937 : Estado Novo, dictature nationaliste et propagandiste. Industrialisation planifiée, économie mixte, pétrole et minerais.",
              "L’État se renforce, la démocratie recule : le développement autocentré a un prix politique.",
            ],
          },
        ],
      },
      {
        title: "II. Les États-Unis : le New Deal, une relance qui ne guérit pas tout",
        subs: [
          {
            title: "A. 1932, le tournant Roosevelt",
            details: [
              "13 millions de chômeurs, banques à terre. Roosevelt, élu en 1932, s’inspire de Keynes : l’État doit dépenser et encadrer.",
            ],
          },
          {
            title: "B. Deux New Deal",
            details: [
              "1933-1934, l’urgence : séparation banques de dépôt et d’affaires, contrôle des marchés, agences, TVA et PWA.",
              "1935-1938, le social : salaires, droit syndical, Social Security Act (1935).",
            ],
          },
          {
            title: "C. Un bilan en demi-teinte",
            details: [
              "La relance améliore la situation sans l’effacer : encore environ 9 millions de chômeurs en 1939.",
            ],
          },
        ],
      },
      {
        title: "III. La France : le Front populaire invente l’État social",
        subs: [
          {
            title: "A. Une République secouée",
            details: [
              "Chômage, populisme, émeutes du 6 février 1934. En avril-mai 1936, le Front populaire (SFIO, radicaux, communistes) porte Blum au pouvoir.",
            ],
          },
          {
            title: "B. Matignon et les lois de juin 1936",
            details: [
              "7-8 juin : CGPF et CGT. Salaires +7 à 15 %, conventions collectives, liberté syndicale. Puis deux semaines de congés payés et semaine de 40 heures.",
            ],
          },
          {
            title: "C. L’expérience s’arrête, l’héritage reste",
            details: [
              "Nationalisations (chemins de fer, armement, aéronautique), réforme de la Banque de France. Hostilité du patronat, démission de Blum en 1937. Les bases de l’État social sont posées.",
            ],
          },
        ],
      },
    ],
    conclusion:
      "Face à la même dépression, les États ont d’abord tenté la déflation, qui a aggravé le mal, puis, pour une partie d’entre eux, la relance keynésienne et le contrôle des marchés, intérieur comme extérieur. Le New Deal et le Front populaire prouvent que l’intervention soulage sans abolir le chômage. Ailleurs, comme au Brésil, la même crise sert de tremplin à un pouvoir autoritaire. La Grande Dépression ne dicte donc pas un seul régime : elle impose partout un État plus lourd, démocratique ou non.",
  },
  {
    id: "s3",
    tag: "Chapitre 1",
    question:
      "Comment la crise de 1929 bouleverse-t-elle les équilibres économiques et sociaux et fragilise-t-elle les modèles économiques en renforçant la place de l’État ?",
    define: ["équilibre économique", "libéralisme", "interventionnisme", "protectionnisme"],
    intro:
      "Sorties de la Grande Guerre, les sociétés des années 1920 ont cru retrouver un équilibre : consommation, oubli, libre-échange. Le krach d’octobre 1929 révèle que cet équilibre était faux, porté par le crédit et par la puissance américaine. Production, salaires, commerce et monnaie s’effondrent ensemble, et les populations se tournent vers l’État. Comment la crise de 1929 détruit-elle les équilibres économiques et sociaux du monde libéral, et en quoi oblige-t-elle les États à changer de modèle, parfois jusqu’à abandonner la démocratie ?",
    parts: [
      {
        title: "I. Un équilibre libéral déjà miné, puis brutalement rompu",
        subs: [
          {
            title: "A. Le faux équilibre des années 1920",
            details: [
              "Surproduction, bulle (cours ×6 de 1926 à 1929), banques dépendantes du crédit court, monde suspendu aux États-Unis.",
            ],
          },
          {
            title: "B. L’effondrement en cascade",
            details: [
              "Jeudi et mardi noirs, 24 milliards de dollars de crédits spéculatifs, faillites bancaires, PIB −30 %, industrie −45 %, exportations mondiales −25 %.",
            ],
          },
          {
            title: "C. La société paie l’addition",
            details: [
              "Chômage à 25 % aux États-Unis, salaires −40 %, Hoovervilles, Dust Bowl, troubles en Europe et chute de 50 % des exportations latino-américaines.",
            ],
          },
        ],
      },
      {
        title: "II. L’État change de place dans l’économie",
        subs: [
          {
            title: "A. L’échec de la déflation",
            details: [
              "Première réponse libérale : baisser salaires et prix. Elle contracte encore la demande et aggrave la crise.",
            ],
          },
          {
            title: "B. La relance keynésienne",
            details: [
              "New Deal (1933-1938) et Front populaire (1936) : dépense publique, protection sociale, hausse fiscale, reprise seulement partielle.",
            ],
          },
          {
            title: "C. Reprendre la main sur les marchés",
            details: [
              "À l’intérieur, réglementation bancaire (séparation dépôt / affaires, Banque de France). À l’extérieur, protectionnisme et zones régionales. Au Brésil, planification et économie mixte.",
            ],
          },
        ],
      },
      {
        title: "III. Le modèle politique libéral sort fragilisé",
        subs: [
          {
            title: "A. Des démocraties qui tiennent, sans convaincre",
            details: [
              "9 millions de chômeurs américains en 1939. Blum chassé par l’hostilité patronale en 1937. La confiance reste entamée.",
            ],
          },
          {
            title: "B. Le repli nationaliste",
            details: [
              "La crise ravive les conséquences de la Grande Guerre : peur, recherche d’un chef, extrême droite.",
            ],
          },
          {
            title: "C. L’autoritaire comme « solution »",
            details: [
              "Estado Novo en 1937. Plus largement, la conclusion du cours : la crise est une des raisons des pouvoirs autoritaires dans le monde, et elle prépare le chapitre sur les totalitarismes.",
            ],
          },
        ],
      },
    ],
    conclusion:
      "La crise de 1929 ne se contente pas de faire baisser les courbes : elle casse l’idée qu’une économie peut s’équilibrer sans l’État, et elle casse la confiance dans les démocraties qui tardent à protéger. L’intervention devient la norme, du New Deal à l’Estado Novo. Là où elle reste démocratique, elle invente du social sans supprimer le chômage. Là où elle devient autoritaire, elle annonce les régimes qui prétendront, dans les années 1930, offrir un modèle entier de remplacement.",
  },
  {
    id: "s4",
    tag: "Chapitre 2",
    question:
      "Ces trois régimes proposent un modèle alternatif à celui des démocraties, reposant sur de nouvelles idéologies.",
    define: ["démocratie", "totalitarisme", "idéologie", "homme nouveau"],
    intro:
      "Là où la démocratie sépare les pouvoirs, tolère le débat et laisse une part de la vie hors de l’État, l’Italie fasciste, l’Allemagne nazie et l’URSS stalinienne prétendent le contraire : une idéologie unique doit fabriquer un homme nouveau et traverser la politique, l’économie et la vie privée. Ce sont des ennemis entre eux — le communisme contre le fascisme — mais des frères par la méthode. Dans quelle mesure ces trois régimes constituent-ils un contre-modèle complet des démocraties, fondé sur des idéologies nouvelles qu’ils transforment en lois, en pouvoir personnel et en société encadrée ?",
    parts: [
      {
        title: "I. Des idéologies nouvelles, traduites en lois",
        subs: [
          {
            title: "A. Trois projets d’homme nouveau",
            details: [
              "URSS : marxisme-léninisme, internationalisme, dictature du prolétariat, homme nouveau travailleur.",
              "Italie : fascisme, nation et État au centre, héritage revendiqué de Rome, homme fort au service de la patrie.",
              "Allemagne : nazisme (Mein Kampf), race, antisémitisme, espace vital, homme aryen.",
            ],
          },
          {
            title: "B. L’idéologie devient la loi",
            details: [
              "Collectivisation et planification dès 1929. Lois fascistissimes de 1925-1926, lois antisémites italiennes de 1938. Lois de Nuremberg le 15 septembre 1935.",
            ],
          },
        ],
      },
      {
        title: "II. Un pouvoir et une économie au service de l’idéologie",
        subs: [
          {
            title: "A. Un chef, un parti, plus d’alternative",
            details: [
              "Staline s’impose en 1927-1928 sur un PCUS unique depuis 1923. Mussolini après la marche sur Rome (1922) et le parti unique (1925), sous la limite du roi. Hitler chancelier le 30 janvier 1933, seul maître après le 2 août 1934, NSDAP unique.",
              "Culte : Vodj, Duce, Führer. Le lien avec le chef remplace la délibération.",
            ],
          },
          {
            title: "B. Le dirigisme n’est pas une politique sociale",
            details: [
              "Kolkhozes et fin des koulaks ; guerre du blé et grands chantiers ; militarisation allemande et exclusion des Juifs de l’économie en 1938.",
              "L’autarcie, dans le cours, ne se conçoit pas sans élargir le territoire : l’économie prépare la conquête.",
            ],
          },
        ],
      },
      {
        title: "III. Une société entière mise au service du régime",
        subs: [
          {
            title: "A. Propagande et censure",
            details: [
              "Stakhanovisme, image de l’Italien modèle, mythe aryen, autodafés, monopole de la presse. Les JO de 1936 montrent la vitrine, et ses limites (Jesse Owens).",
            ],
          },
          {
            title: "B. Embrigader pour être aimé, terroriser pour être obéi",
            details: [
              "Komsomol, Balilla, Jeunesses hitlériennes, Dopolavoro.",
              "OVRA, Gestapo, NKVD, Nuit des Longs Couteaux, famine ukrainienne, Nuit de Cristal, Graziani. Aron : les cinq traits sont réunis, donc le mot totalitaire est juste.",
            ],
          },
        ],
      },
    ],
    conclusion:
      "Ces régimes ne sont pas de simples dictatures militaires. Ils proposent un modèle entier, hostile au pluralisme : une idéologie, un chef, une économie dirigée, une société surveillée jusque dans ses loisirs. Le contre-modèle a pourtant des failles — le roi et le pape en Italie, les résistances en Allemagne, les campagnes soviétiques — et il est tourné vers l’extérieur : l’autarcie et l’espace vital annoncent la guerre que le chapitre suivant voit s’ouvrir.",
  },
  {
    id: "s5",
    tag: "Chapitre 2",
    question:
      "Comment les régimes totalitaires, antagonistes ou alliés, ont-ils déstabilisé les sociétés européennes ?",
    define: ["totalitarisme", "antagonistes", "attentisme", "SDN"],
    intro:
      "Entre 1922 et 1939, trois régimes que tout oppose sur le papier — le communisme stalinien, le fascisme, le nazisme — transforment l’Europe. Chacun fait la guerre à sa propre société, au nom d’un homme nouveau. En même temps, ils s’exportent dans les démocraties par des partis, puis se coalisent ou se trahissent selon l’intérêt. Comment ces régimes, tantôt ennemis et tantôt alliés, ont-ils déstabilisé les sociétés européennes, au-dedans de leurs frontières comme au-dehors, jusqu’à rendre la guerre possible ?",
    parts: [
      {
        title: "I. Ils déstabilisent d’abord leurs propres sociétés",
        subs: [
          {
            title: "A. Une emprise qui ne s’arrête pas à l’opposant",
            details: [
              "Cinq traits d’Aron. Famine ukrainienne (1932-1933), Grande Terreur (1936-1938), Nuit de Cristal (1938), massacre de Graziani (1937) : la violence frappe des populations, pas seulement des militants.",
            ],
          },
          {
            title: "B. L’embrigadement ne ferme pas toutes les bouches",
            details: [
              "Jeunesses et loisirs encadrés, mais limites : roi et pape, oppositions du Nord italien, résistances allemandes y compris dans l’armée, révoltes et freinage du travail en URSS.",
              "Déstabiliser n’est pas convaincre. Le régime tient aussi parce qu’il fait peur.",
            ],
          },
        ],
      },
      {
        title: "II. Ils divisent les démocraties de l’intérieur",
        subs: [
          {
            title: "A. Des partis qui répondent à l’étranger",
            details: [
              "Communistes reliés à Moscou, perçus à droite comme des ennemis intérieurs. British Union of Fascists de Mosley (1932-1940). PPF de Doriot (1936-1945), qui recycle les ligues dissoutes en 1936.",
            ],
          },
          {
            title: "B. Le pacifisme comme faille",
            details: [
              "« Plus jamais ça », surtout sous le Front populaire à partir de 1936, explique des réactions seulement verbales. La société démocratique est séduite ou tétanisée, rarement unie.",
            ],
          },
        ],
      },
      {
        title: "III. Antagonistes puis alliés, ils cassent l’ordre européen",
        subs: [
          {
            title: "A. D’abord un front contre les démocraties et contre Moscou",
            details: [
              "Rhénanie le 7 mars 1936, axe Rome-Berlin en octobre, pacte anti-Komintern le 25 novembre 1936. La guerre d’Espagne sert de répétition. L’Italie quitte l’esprit de Stresa (1935).",
            ],
          },
          {
            title: "B. L’alliance de l’été 1939, qui rend l’invasion possible",
            details: [
              "Anschluss (mars 1938), Munich (septembre 1938, sans l’URSS), fin de la Tchécoslovaquie (mars 1939), pacte d’acier (22 mai).",
              "23 août 1939 : Hitler et Staline, ennemis idéologiques, signent. Clauses secrètes sur la Pologne. Le 1er septembre, l’Allemagne envahit. Le 3, Paris et Londres entrent en guerre.",
            ],
          },
        ],
      },
    ],
    conclusion:
      "La déstabilisation est double. Au-dedans, les totalitarismes refont leurs sociétés par l’idéologie et la terreur, sans jamais obtenir une adhésion totale. Au-dehors, ils exploitent le pacifisme, noyautent la vie politique et passent de l’hostilité à l’alliance dès que la Pologne est en jeu. Les démocraties, en cédant de la Rhénanie à Munich, ont paru faibles. Ce sont les régimes totalitaires qui choisissent l’heure de la guerre.",
  },
  {
    id: "s6",
    tag: "Mixte",
    question:
      "Comment la crise de 1929 fragilise-t-elle les démocraties et favorise-t-elle l’émergence de modèles alternatifs ?",
    define: ["démocratie libérale", "crise de 1929", "totalitarisme", "interventionnisme"],
    intro:
      "La prospérité fragile des années 1920 reposait sur le crédit américain et sur l’idée libérale que l’État doit peu intervenir. Le krach d’octobre 1929 ouvre une dépression qui appauvrit les sociétés et discrédite les gouvernements incapables de l’arrêter. Certains restent des démocraties et inventent l’intervention ; d’autres basculent vers des régimes qui promettent un ordre total. Comment la crise de 1929 fragilise-t-elle les démocraties, et en quoi ouvre-t-elle la voie à des modèles autoritaires puis totalitaires qui prétendent la dépasser ?",
    parts: [
      {
        title: "I. Une crise qui ruine la confiance dans le modèle libéral",
        subs: [
          {
            title: "A. Du krach à la dépression",
            details: [
              "24 et 29 octobre 1929. PIB −30 %, industrie −45 %, chômage américain à 25 % en 1933, salaires −40 %.",
            ],
          },
          {
            title: "B. Une misère qui devient politique",
            details: [
              "Hoovervilles, 6 février 1934 en France, exportations latino-américaines −50 %. Les trois piliers — production, commerce, étalon-or — s’effondrent.",
            ],
          },
        ],
      },
      {
        title: "II. Les démocraties répondent, sans retrouver l’avant-crise",
        subs: [
          {
            title: "A. Déflation, puis relance",
            details: [
              "La baisse des salaires aggrave le mal. Keynes inspire le New Deal : urgence bancaire et travaux (1933-1934), puis Social Security Act (1935).",
              "En France, Matignon (7-8 juin 1936), 40 heures, congés payés, nationalisations.",
            ],
          },
          {
            title: "B. Le doute demeure",
            details: [
              "9 millions de chômeurs américains en 1939. Blum démissionne en 1937. L’État social naît, mais la peur reste, et avec elle l’extrême droite.",
              "La SDN, plus tard, héritera de cette image de faiblesse.",
            ],
          },
        ],
      },
      {
        title: "III. Des modèles alternatifs occupent le vide",
        subs: [
          {
            title: "A. L’autoritaire de crise",
            details: [
              "Vargas et l’Estado Novo en 1937 : nationalisme, propagande, planification. La crise sert de prétexte à la dictature.",
            ],
          },
          {
            title: "B. Le totalitaire comme système complet",
            details: [
              "Hitler arrive au pouvoir le 30 janvier 1933, en pleine dépression allemande. Les cinq traits d’Aron s’ajoutent à la promesse de relever la nation.",
              "Même l’URSS, née avant 1929, durcit sa marche forcée avec la collectivisation de 1929 : la crise mondiale confirme, pour ces régimes, que le libéralisme est mort.",
            ],
          },
          {
            title: "C. De la fragilité intérieure à la guerre",
            details: [
              "Les démocraties, marquées par « plus jamais ça », cèdent de la Rhénanie (1936) à Munich (1938). Le pacte du 23 août 1939 et l’invasion de la Pologne montrent le prix de cette fragilité.",
            ],
          },
        ],
      },
    ],
    conclusion:
      "La crise de 1929 n’a pas « créé » tous les totalitarismes : l’Italie fasciste et l’URSS lui sont antérieures. Elle a en revanche détruit la croyance dans le laissez-faire, épuisé la patience des sociétés et offert aux régimes à idéologie une preuve et un public. Les démocraties qui interviennent limitent la casse sans retrouver la confiance. Celles qui cèdent ensuite, sur la scène internationale, laissent le champ libre à des États qui ont fait de la force leur principe, jusqu’à la guerre de septembre 1939.",
  },
];

export const QUIZZES: QuizItem[] = [
  { id: "q1", tag: "date", q: "Le jeudi noir, c’est le…", choices: ["24 octobre 1929", "29 octobre 1929", "24 octobre 1928", "6 février 1934"], answer: 0, why: "24 octobre = jeudi noir = 12 millions d’actions. Le 29 est le mardi noir." },
  { id: "q2", tag: "date", q: "Le mardi noir, combien d’actions supplémentaires ?", choices: ["16 millions", "12 millions", "24 milliards", "6 millions"], answer: 0, why: "29 octobre 1929 : 16 millions d’actions. Les 24 milliards, ce sont les prêts des six banques." },
  { id: "q3", tag: "fait", q: "Entre 1929 et 1933, le PIB américain…", choices: ["chute d’environ 30 %", "chute de 50 %", "stagne", "est multiplié par 6"], answer: 0, why: "PIB −30 %. La production industrielle, elle, chute de 45 %. Les ×6, c’est la bulle d’avant le krach." },
  { id: "q4", tag: "fait", q: "En 1933, la part des Américains sans emploi est d’environ…", choices: ["25 %", "10 %", "40 %", "5 %"], answer: 0, why: "25 %, soit près de 13 millions de personnes, un quart de la population active. −40 %, ce sont les salaires." },
  { id: "q5", tag: "notion", q: "Un kolkhoze est…", choices: ["une ferme collective soviétique", "un paysan riche persécuté", "un camp de travail", "la jeunesse communiste"], answer: 0, why: "Kolkhoze = terre mise en commun. Koulak = paysan aisé. Goulag = camp. Komsomol = jeunesse." },
  { id: "q6", tag: "date", q: "Hitler est nommé chancelier le…", choices: ["30 janvier 1933", "2 août 1934", "7 mars 1936", "23 août 1939"], answer: 0, why: "30 janvier 1933, par Hindenburg. Le 2 août 1934, Hindenburg meurt et Hitler reste seul." },
  { id: "q7", tag: "date", q: "Les accords Matignon sont signés…", choices: ["les 7 et 8 juin 1936", "le 6 février 1934", "en avril 1936 seulement", "en 1937, au départ de Blum"], answer: 0, why: "7-8 juin 1936, CGPF contre CGT. Le 6 février 1934, ce sont les émeutes. Blum démissionne en 1937." },
  { id: "q8", tag: "notion", q: "La première réaction libérale à la crise, c’est…", choices: ["la déflation, qui aggrave la crise", "le New Deal", "les congés payés", "la collectivisation"], answer: 0, why: "Déflation → baisse des salaires → la crise empire. Le New Deal est la deuxième réaction, keynésienne." },
  { id: "q9", tag: "date", q: "Les lois de Nuremberg datent du…", choices: ["15 septembre 1935", "9 novembre 1938", "29 juin 1934", "30 janvier 1933"], answer: 0, why: "1935 : les Juifs perdent la citoyenneté. 9-10 novembre 1938 : Nuit de Cristal. Juin 1934 : Longs Couteaux." },
  { id: "q10", tag: "notion", q: "L’OVRA est…", choices: ["la police politique fasciste, 1927", "la milice des chemises brunes", "la police nazie de Göring", "le syndicat signataire de Matignon"], answer: 0, why: "OVRA = Italie, 1927. SA = milice nazie. Gestapo = police nazie, 1933. CGT = syndicat de Matignon." },
  { id: "q11", tag: "date", q: "La Rhénanie est remilitarisée le…", choices: ["7 mars 1936", "12 mars 1938", "22 mai 1939", "1er septembre 1939"], answer: 0, why: "7 mars 1936, violation de Versailles. 12 mars 1938 = entrée en Autriche. 22 mai 1939 = pacte d’acier." },
  { id: "q12", tag: "fait", q: "Le Social Security Act est une loi…", choices: ["américaine de 1935, assurances sociales", "française de 1936, congés payés", "nazie de 1935, citoyenneté", "brésilienne de 1937"], answer: 0, why: "C’est le cœur du second New Deal. Les congés payés sont français. Nuremberg est la loi nazie de 1935." },
  { id: "q13", tag: "notion", q: "Selon le cours, un koulak est…", choices: ["un paysan aisé visé par la collectivisation", "un ouvrier modèle", "le chef du NKVD", "un membre du Komsomol"], answer: 0, why: "Le koulak est l’ennemi de classe des campagnes. L’ouvrier modèle, c’est le stakhanovisme." },
  { id: "q14", tag: "date", q: "L’Anschluss est proclamé le…", choices: ["13 mars 1938", "12 septembre 1938", "30 septembre 1938", "23 août 1939"], answer: 0, why: "La Wehrmacht entre le 12 mars, l’annexion est proclamée le 13. Munich est en septembre. Le pacte, le 23 août 1939." },
  { id: "q15", tag: "fait", q: "À la conférence de Munich, qui n’est pas là ?", choices: ["Staline", "Hitler", "Daladier", "Chamberlain"], answer: 0, why: "Sont présents Hitler, Mussolini, Daladier et Chamberlain. L’URSS est tenue à l’écart et s’en souviendra en août 1939." },
  { id: "q16", tag: "date", q: "Le pacte germano-soviétique est signé le…", choices: ["23 août 1939", "22 mai 1939", "25 novembre 1936", "3 septembre 1939"], answer: 0, why: "23 août : Ribbentrop-Molotov. 22 mai : pacte d’acier. 25 novembre 1936 : anti-Komintern. 3 septembre : déclaration de guerre." },
  { id: "q17", tag: "date", q: "La France et le Royaume-Uni déclarent la guerre le…", choices: ["3 septembre 1939", "1er septembre 1939", "23 août 1939", "juin 1940"], answer: 0, why: "L’Allemagne envahit la Pologne le 1er. Paris et Londres déclarent la guerre le 3. L’Italie attend juin 1940." },
  { id: "q18", tag: "notion", q: "Le front de Stresa, en 1935, réunit…", choices: ["France, Italie et Royaume-Uni contre Hitler", "Allemagne, Italie et Japon", "Allemagne et URSS", "seulement la France et l’URSS"], answer: 0, why: "Stresa est une entente antifasciste du côté allemand, pas un axe. Elle meurt quand Rome se tourne vers Berlin." },
  { id: "q19", tag: "fait", q: "Les exportations de l’Amérique latine, entre 1929 et 1932…", choices: ["chutent d’environ 50 %", "chutent de 25 %", "chutent de 10 %", "augmentent grâce à Vargas"], answer: 0, why: "−50 % en moyenne. −25 %, ce sont les exportations mondiales. Vargas arrive comme réponse politique, en 1937." },
  { id: "q20", tag: "date", q: "La Nuit des Longs Couteaux, c’est…", choices: ["29-30 juin 1934, environ 85 SA tués par les SS", "9-10 novembre 1938, un pogrom", "19 février 1937, Addis-Abeba", "20 juillet 1944, un complot d’officiers"], answer: 0, why: "Purge interne nazie. La Nuit de Cristal est le pogrom de 1938. Graziani est en Éthiopie. Von Witzleben, c’est 1944." },
  { id: "q21", tag: "notion", q: "Le cinquième trait du totalitarisme, dans le cours, c’est…", choices: ["un dirigisme tourné vers l’autarcie et la conquête", "des élections libres régulières", "un roi qui limite le chef", "la seule censure des journaux"], answer: 0, why: "Parti, idéologie, terreur, médias, et dirigisme-autarcie-conquête. Le roi qui limite Mussolini montre au contraire que l’Italie n’embrigade pas tout." },
  { id: "q22", tag: "fait", q: "Matignon accorde une hausse des salaires de…", choices: ["7 à 15 %", "40 %", "50 %", "99,75 %"], answer: 0, why: "+7 à 15 %. −40 %, ce sont les salaires américains pendant la dépression. 99,75 %, le plébiscite de l’Anschluss." },
  { id: "q23", tag: "date", q: "L’Estado Novo de Vargas est instauré en…", choices: ["1937", "1929", "1933", "1936"], answer: 0, why: "1937, dictature brésilienne. 1933, c’est Hitler et le New Deal. 1936, le Front populaire." },
  { id: "q24", tag: "notion", q: "Les Balilla sont…", choices: ["les jeunesses fascistes italiennes", "les jeunesses communistes", "les jeunesses hitlériennes", "l’organisation des loisirs adultes"], answer: 0, why: "Balilla = Italie, discipline et préparation militaire. Komsomol = URSS. Jeunesses hitlériennes = Allemagne. Loisirs adultes italiens = Dopolavoro." },
  { id: "q25", tag: "fait", q: "En 1939, après le New Deal, les États-Unis comptent encore environ…", choices: ["9 millions de chômeurs", "13 millions de chômeurs", "25 millions de chômeurs", "aucun chômage"], answer: 0, why: "Le cours insiste sur la limite : 9 millions en 1939. Les 13 millions, c’est le pic de 1933." },
  { id: "q26", tag: "date", q: "Le pacte d’acier est signé le…", choices: ["22 mai 1939, entre Allemagne et Italie", "23 août 1939, entre Allemagne et URSS", "octobre 1936, axe encore informel", "7 mars 1936"], answer: 0, why: "Pacte d’acier = alliance militaire offensive du 22 mai 1939. L’axe d’octobre 1936 en est la préparation politique." },
  { id: "q27", tag: "notion", q: "Une Hooverville est…", choices: ["un bidonville de chômeurs américains", "une agence du New Deal", "une ferme collective", "une marche de la faim britannique"], answer: 0, why: "Le surnom vise le président Hoover. Les marches de la faim, c’est le Royaume-Uni en 1932. TVA et PWA sont les agences." },
  { id: "q28", tag: "fait", q: "Six grandes banques américaines ont prêté à la spéculation environ…", choices: ["24 milliards de dollars", "24 millions de dollars", "12 millions de dollars", "6 milliards de dollars"], answer: 0, why: "24 milliards. Ne pas confondre avec les 12 et 16 millions d’actions des jours noirs." },
];
