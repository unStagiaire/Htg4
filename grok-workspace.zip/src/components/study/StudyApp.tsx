import { useEffect, useMemo, useState } from "react";
import {
  BookOpen,
  CalendarDays,
  Check,
  ChevronDown,
  Library,
  PenLine,
  RotateCcw,
  ScrollText,
  Search,
} from "lucide-react";
import {
  COMPARE,
  EVENTS,
  FIGURES,
  GLOSSARY,
  LESSONS,
  QUIZZES,
  STORIES,
  SUBJECTS,
  TRAPS,
  type Chapter,
  type QuizItem,
  type RqpSubject,
  type Tone,
} from "@/data/content";
import { MemoryProvider, useMemory, type Grade } from "@/components/study/memory";

type Tab = "cours" | "dates" | "mots" | "recits" | "rqp";

const TONE_BAR: Record<Tone, string> = {
  crisis: "border-crisis",
  terror: "border-terror",
  demo: "border-demo",
  geo: "border-geo",
};
const TONE_DOT: Record<Tone, string> = {
  crisis: "bg-crisis",
  terror: "bg-terror",
  demo: "bg-demo",
  geo: "bg-geo",
};
const TONE_SOFT: Record<Tone, string> = {
  crisis: "bg-crisisbg text-crisis",
  terror: "bg-terrorbg text-terror",
  demo: "bg-demobg text-demo",
  geo: "bg-geobg text-geo",
};

function norm(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "");
}

function Rich({
  text,
  onTerm,
}: {
  text: string;
  onTerm?: (label: string) => void;
}) {
  const parts = text.split(/(\[\[[^\]]+\]\]|\{\{[^}]+\}\})/g);
  return (
    <>
      {parts.map((part, index) => {
        if (part.startsWith("[[") && part.endsWith("]]")) {
          return (
            <span
              key={index}
              className="mx-0.5 inline-block rounded bg-datebg px-1.5 py-0.5 text-xs font-semibold text-date"
            >
              {part.slice(2, -2)}
            </span>
          );
        }
        if (part.startsWith("{{") && part.endsWith("}}")) {
          const label = part.slice(2, -2);
          return (
            <button
              key={index}
              type="button"
              onClick={() => onTerm?.(label)}
              className="mx-0.5 inline border-b border-crisis/50 font-semibold text-crisis"
            >
              {label}
            </button>
          );
        }
        return <span key={index}>{part}</span>;
      })}
    </>
  );
}

function GradeButtons({ id }: { id: string }) {
  const { grades, grade } = useMemory();
  const current = grades[id];
  return (
    <div className="mt-3 flex gap-2">
      <button
        type="button"
        onClick={() => grade(id, "ok")}
        className={
          "flex min-h-11 flex-1 items-center justify-center gap-1.5 rounded-xl text-sm font-semibold " +
          (current === "ok" ? "bg-demo text-sheet" : "bg-demobg text-demo")
        }
      >
        <Check className="size-4" />
        Je sais
      </button>
      <button
        type="button"
        onClick={() => grade(id, "again")}
        className={
          "flex min-h-11 flex-1 items-center justify-center gap-1.5 rounded-xl text-sm font-semibold " +
          (current === "again" ? "bg-terror text-sheet" : "bg-terrorbg text-terror")
        }
      >
        <RotateCcw className="size-4" />
        À revoir
      </button>
    </div>
  );
}

function Chip({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        "shrink-0 rounded-full px-3 py-2 text-sm font-semibold " +
        (active ? "bg-ink text-sheet" : "bg-paper text-muted")
      }
    >
      {children}
    </button>
  );
}

function Cours({ onTerm }: { onTerm: (label: string) => void }) {
  const [chapter, setChapter] = useState<Chapter | "tout">("crise");
  const [query, setQuery] = useState("");
  const q = norm(query.trim());
  const lessons = LESSONS.filter((lesson) => {
    if (chapter !== "tout" && lesson.chapter !== chapter) return false;
    if (!q) return true;
    const blob = norm([lesson.title, lesson.remember, ...lesson.points].join(" "));
    return blob.includes(q);
  });

  return (
    <div>
      <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 pt-4">
        {(
          [
            ["crise", "Crise"],
            ["regimes", "Régimes"],
            ["monde", "Monde"],
            ["tout", "Tout"],
          ] as const
        ).map(([id, label]) => (
          <Chip key={id} active={chapter === id} onClick={() => setChapter(id)}>
            {label}
          </Chip>
        ))}
      </div>
      <label className="mx-4 mt-3 flex items-center gap-2 rounded-xl border border-line bg-paper px-3">
        <Search className="size-4 text-muted" />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Chercher un fait, une date, un nom"
          className="min-h-11 w-full bg-transparent text-sm outline-none"
        />
      </label>

      {(chapter === "crise" || chapter === "tout") && !q && (
        <div className="no-scrollbar mt-4 flex gap-2 overflow-x-auto px-4">
          {FIGURES.map((figure) => (
            <article
              key={figure.id}
              className="w-36 shrink-0 snap-start rounded-2xl border border-line bg-datebg p-3"
            >
              <p className="font-serif text-2xl text-date">{figure.n}</p>
              <p className="mt-1 text-xs leading-snug text-ink">{figure.label}</p>
            </article>
          ))}
        </div>
      )}

      {chapter === "regimes" && !q && <Compare />}

      {(chapter === "crise" || chapter === "tout") && !q && <TwoReactions />}

      <div className="space-y-3 px-4 py-4">
        {lessons.length === 0 && (
          <p className="rounded-2xl bg-paper px-4 py-6 text-sm text-muted">
            Rien sous cette recherche. Essaie un nom (Blum, kolkhoze) ou une année.
          </p>
        )}
        {lessons.map((lesson) => (
          <LessonCard key={lesson.id} lessonId={lesson.id} forceOpen={q.length > 1} onTerm={onTerm} />
        ))}
      </div>
    </div>
  );
}

function LessonCard({
  lessonId,
  forceOpen,
  onTerm,
}: {
  lessonId: string;
  forceOpen: boolean;
  onTerm: (label: string) => void;
}) {
  const lesson = LESSONS.find((item) => item.id === lessonId)!;
  const [manual, setManual] = useState<boolean | null>(null);
  useEffect(() => {
    setManual(null);
  }, [forceOpen]);
  const open = manual ?? forceOpen;

  return (
    <article className={"overflow-hidden rounded-2xl border border-line border-l-4 bg-sheet " + TONE_BAR[lesson.tone]}>
      <button
        type="button"
        aria-expanded={open}
        onClick={() => setManual(!open)}
        className="flex w-full items-start gap-3 px-4 py-3 text-left"
      >
        <span className="flex-1">
          <span className="block font-semibold">{lesson.title}</span>
          {!open && <span className="mt-1 block text-sm text-muted">{lesson.remember}</span>}
        </span>
        <ChevronDown className={"mt-1 size-4 shrink-0 text-muted " + (open ? "rotate-180" : "")} />
      </button>
      {open && (
        <div className="border-t border-line px-4 py-3">
          <p className="rounded-xl bg-datebg px-3 py-2 text-sm font-semibold text-ink">
            <Rich text={lesson.remember} onTerm={onTerm} />
          </p>
          <ul className="mt-3 space-y-2.5 text-sm">
            {lesson.points.map((point) => (
              <li key={point} className="flex gap-2">
                <span className={"mt-1.5 size-1.5 shrink-0 rounded-full " + TONE_DOT[lesson.tone]} />
                <span>
                  <Rich text={point} onTerm={onTerm} />
                </span>
              </li>
            ))}
          </ul>
          <GradeButtons id={"lecon:" + lesson.id} />
        </div>
      )}
    </article>
  );
}

function TwoReactions() {
  return (
    <section className="mx-4 mt-4 grid gap-2">
      <h2 className="font-serif text-lg">Les deux réactions à retenir</h2>
      <article className="rounded-2xl bg-terrorbg p-3 text-sm">
        <p className="font-semibold text-terror">1. Libéralisme · déflation</p>
        <p className="mt-1">Baisse des salaires, puis aggravation de la crise.</p>
      </article>
      <article className="rounded-2xl bg-demobg p-3 text-sm">
        <p className="font-semibold text-demo">2. Keynésianisme · relance</p>
        <p className="mt-1">
          Dépense publique, protection sociale, impôts en hausse, reprise partielle. New Deal et Front populaire.
        </p>
      </article>
      <article className="rounded-2xl bg-geobg p-3 text-sm">
        <p className="font-semibold text-geo">Et le politique</p>
        <p className="mt-1">
          Contrôle des marchés, protectionnisme, puis régimes autoritaires : repli, nationalisme, extrême droite.
        </p>
      </article>
    </section>
  );
}

function Compare() {
  const [row, setRow] = useState(COMPARE[0].id);
  const current = COMPARE.find((item) => item.id === row) ?? COMPARE[0];
  const cells = [
    ["Italie", current.it, "terror" as Tone],
    ["Allemagne", current.de, "terror" as Tone],
    ["URSS", current.su, "terror" as Tone],
  ];
  return (
    <section className="mt-4">
      <h2 className="px-4 font-serif text-lg">Le tableau des trois régimes</h2>
      <p className="px-4 text-sm text-muted">Une ligne à la fois. Compare avant de dérouler le cours.</p>
      <div className="no-scrollbar mt-2 flex gap-2 overflow-x-auto px-4">
        {COMPARE.map((item) => (
          <Chip key={item.id} active={item.id === row} onClick={() => setRow(item.id)}>
            {item.label}
          </Chip>
        ))}
      </div>
      <div className="grid gap-2 px-4 pt-3">
        {cells.map(([name, text]) => (
          <article key={name} className="rounded-2xl border border-line p-3">
            <p className="text-xs font-semibold tracking-wide text-terror uppercase">{name}</p>
            <p className="mt-1 text-sm">{text}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

function Dates() {
  const [mode, setMode] = useState<"frise" | "test" | "pieges">("frise");
  const pool = QUIZZES.filter((item) => item.tag === "date");
  return (
    <div>
      <div className="flex gap-2 px-4 pt-4">
        <Chip active={mode === "frise"} onClick={() => setMode("frise")}>
          Frise
        </Chip>
        <Chip active={mode === "test"} onClick={() => setMode("test")}>
          Test de dates
        </Chip>
        <Chip active={mode === "pieges"} onClick={() => setMode("pieges")}>
          Pièges
        </Chip>
      </div>
      {mode === "frise" && (
        <ol className="px-4 py-4">
          {EVENTS.map((event) => (
            <li key={event.id} className="flex gap-3">
              <div className="flex w-4 flex-col items-center">
                <span className={"mt-3 size-3 shrink-0 rounded-full " + TONE_DOT[event.tone]} />
                <span className="mt-1 w-0.5 flex-1 bg-line" />
              </div>
              <article className="mb-3 flex-1 rounded-2xl border border-line p-3">
                <p className={"inline-block rounded px-1.5 py-0.5 text-xs font-semibold " + TONE_SOFT[event.tone]}>
                  {event.when}
                </p>
                <h3 className="mt-1 text-base font-semibold">{event.title}</h3>
                <p className="mt-1 text-sm text-muted">{event.text}</p>
                <GradeButtons id={"date:" + event.id} />
              </article>
            </li>
          ))}
        </ol>
      )}
      {mode === "test" && <Qcm items={pool} title="Dates seules" />}
      {mode === "pieges" && (
        <div className="space-y-3 px-4 py-4">
          {TRAPS.map((trap) => (
            <TrapCard key={trap.id} id={trap.id} />
          ))}
        </div>
      )}
    </div>
  );
}

function TrapCard({ id }: { id: string }) {
  const trap = TRAPS.find((item) => item.id === id)!;
  const [open, setOpen] = useState(false);
  return (
    <article className="rounded-2xl border border-line p-3">
      <p className="text-xs font-semibold text-terror">Le faux réflexe</p>
      <p className="mt-1 text-sm font-semibold">{trap.wrong}</p>
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        className="mt-3 min-h-11 w-full rounded-xl bg-paper text-sm font-semibold"
      >
        {open ? "Cacher la correction" : "Voir la distinction"}
      </button>
      {open && <p className="mt-2 text-sm">{trap.right}</p>}
    </article>
  );
}

function Mots({
  query,
  onQuery,
}: {
  query: string;
  onQuery: (value: string) => void;
}) {
  const [chapter, setChapter] = useState<Chapter | "tout">("tout");
  const [mode, setMode] = useState<"cartes" | "liste">("cartes");
  const { grades, reset } = useMemory();
  const [armed, setArmed] = useState(false);
  const q = norm(query.trim());
  const terms = GLOSSARY.filter((entry) => {
    if (chapter !== "tout" && entry.chapter !== chapter) return false;
    if (!q) return true;
    return norm(entry.term + " " + entry.def).includes(q);
  });
  const ordered = useMemo(() => {
    const rank = (id: string) => (grades[id] === "again" ? 0 : grades[id] === "ok" ? 2 : 1);
    return [...terms].sort((a, b) => rank("mot:" + a.id) - rank("mot:" + b.id));
  }, [terms, grades]);

  return (
    <div>
      <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 pt-4">
        {(
          [
            ["tout", "Tous"],
            ["crise", "Crise"],
            ["regimes", "Régimes"],
            ["monde", "Monde"],
          ] as const
        ).map(([id, label]) => (
          <Chip key={id} active={chapter === id} onClick={() => setChapter(id)}>
            {label}
          </Chip>
        ))}
      </div>
      <div className="mt-3 flex gap-2 px-4">
        <Chip active={mode === "cartes"} onClick={() => setMode("cartes")}>
          Cartes
        </Chip>
        <Chip active={mode === "liste"} onClick={() => setMode("liste")}>
          Liste
        </Chip>
      </div>
      <label className="mx-4 mt-3 flex items-center gap-2 rounded-xl border border-line bg-paper px-3">
        <Search className="size-4 text-muted" />
        <input
          value={query}
          onChange={(event) => onQuery(event.target.value)}
          placeholder="kolkhoze, Matignon, espace vital…"
          className="min-h-11 w-full bg-transparent text-sm outline-none"
        />
      </label>
      {mode === "cartes" ? (
        <FlashDeck key={chapter + q} ids={ordered.map((entry) => entry.id)} />
      ) : (
        <ul className="space-y-2 px-4 py-4">
          {ordered.map((entry) => (
            <GlossaryRow key={entry.id} id={entry.id} />
          ))}
        </ul>
      )}
      <div className="px-4 pb-6">
        <button
          type="button"
          onClick={() => {
            if (!armed) {
              setArmed(true);
              return;
            }
            reset();
            setArmed(false);
          }}
          className="text-sm text-muted underline"
        >
          {armed ? "Confirmer l’effacement des scores" : "Effacer mes scores sur cet appareil"}
        </button>
      </div>
    </div>
  );
}

function GlossaryRow({ id }: { id: string }) {
  const entry = GLOSSARY.find((item) => item.id === id)!;
  const [open, setOpen] = useState(false);
  return (
    <li className="rounded-2xl border border-line">
      <button type="button" onClick={() => setOpen((value) => !value)} className="flex min-h-11 w-full items-center justify-between px-3 text-left">
        <span className="font-semibold">{entry.term}</span>
        <ChevronDown className={"size-4 text-muted " + (open ? "rotate-180" : "")} />
      </button>
      {open && (
        <div className="px-3 pb-3 text-sm">
          <p>{entry.def}</p>
          {entry.example && <p className="mt-1 text-muted">{entry.example}</p>}
          <GradeButtons id={"mot:" + entry.id} />
        </div>
      )}
    </li>
  );
}

function FlashDeck({ ids }: { ids: string[] }) {
  const [deck] = useState(ids);
  const [cursor, setCursor] = useState(0);
  const [face, setFace] = useState<"term" | "def">("term");
  const id = deck[cursor];
  const entry = GLOSSARY.find((item) => item.id === id);
  if (!entry) {
    return <p className="px-4 py-6 text-sm text-muted">Aucun mot pour ce filtre.</p>;
  }
  return (
    <div className="px-4 py-4">
      <p className="text-xs text-muted">
        {cursor + 1} / {deck.length} · les « à revoir » passent devant
      </p>
      <button
        type="button"
        onClick={() => setFace((value) => (value === "term" ? "def" : "term"))}
        className="mt-2 flex min-h-52 w-full flex-col items-start justify-center rounded-3xl border border-line bg-paper p-5 text-left"
      >
        {face === "term" ? (
          <>
            <span className="text-xs font-semibold tracking-wide text-crisis uppercase">Essaie avant de retourner</span>
            <span className="mt-2 font-serif text-3xl">{entry.term}</span>
            <span className="mt-4 text-sm text-muted">Touche la carte pour la définition.</span>
          </>
        ) : (
          <>
            <span className="font-serif text-xl">{entry.term}</span>
            <span className="mt-3 text-sm">{entry.def}</span>
            {entry.example && <span className="mt-2 text-sm text-muted">{entry.example}</span>}
          </>
        )}
      </button>
      <GradeButtons id={"mot:" + entry.id} />
      <button
        type="button"
        onClick={() => {
          setCursor((value) => (value + 1) % deck.length);
          setFace("term");
        }}
        className="mt-2 min-h-11 w-full rounded-xl bg-ink text-sm font-semibold text-sheet"
      >
        Mot suivant
      </button>
    </div>
  );
}

function Recits() {
  return (
    <div className="space-y-3 px-4 py-4">
      <p className="text-sm text-muted">
        Lis seulement le titre. Réponds aux trois questions dans ta tête. Ensuite seulement, ouvre le récit.
      </p>
      {STORIES.map((story) => (
        <StoryCard key={story.id} id={story.id} />
      ))}
    </div>
  );
}

function StoryCard({ id }: { id: string }) {
  const story = STORIES.find((item) => item.id === id)!;
  const [open, setOpen] = useState(false);
  return (
    <article className={"rounded-2xl border border-line border-l-4 p-3 " + TONE_BAR[story.tone]}>
      <p className={"inline-block rounded px-1.5 py-0.5 text-xs font-semibold " + TONE_SOFT[story.tone]}>
        {story.date} · {story.place}
      </p>
      <h3 className="mt-1 font-serif text-xl">{story.title}</h3>
      <ul className="mt-2 space-y-1 text-sm text-muted">
        {story.prompts.map((prompt) => (
          <li key={prompt}>{prompt}</li>
        ))}
      </ul>
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        className="mt-3 min-h-11 w-full rounded-xl bg-ink text-sm font-semibold text-sheet"
      >
        {open ? "Cacher le récit" : "Afficher le récit"}
      </button>
      {open && (
        <div className="mt-3 text-sm">
          <ol className="space-y-2">
            {story.beats.map((beat, index) => (
              <li key={beat} className="flex gap-2">
                <span className="font-semibold text-date">{index + 1}.</span>
                <span>{beat}</span>
              </li>
            ))}
          </ol>
          <p className="mt-3 rounded-xl bg-datebg p-3">
            <span className="font-semibold">Dans une copie. </span>
            {story.copie}
          </p>
          <GradeButtons id={"recit:" + story.id} />
        </div>
      )}
    </article>
  );
}

function Rqp({ onTerm }: { onTerm: (label: string) => void }) {
  const [mode, setMode] = useState<"plans" | "qcm" | "methode">("plans");
  const [subjectId, setSubjectId] = useState(SUBJECTS[0].id);
  return (
    <div>
      <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 pt-4">
        <Chip active={mode === "plans"} onClick={() => setMode("plans")}>
          Plans
        </Chip>
        <Chip active={mode === "methode"} onClick={() => setMode("methode")}>
          Méthode
        </Chip>
        <Chip active={mode === "qcm"} onClick={() => setMode("qcm")}>
          QCM
        </Chip>
      </div>
      {mode === "methode" && <Method />}
      {mode === "qcm" && <Qcm items={QUIZZES} title="Les deux chapitres mélangés" />}
      {mode === "plans" && (
        <>
          <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 pt-3">
            {SUBJECTS.map((subject, index) => (
              <Chip key={subject.id} active={subject.id === subjectId} onClick={() => setSubjectId(subject.id)}>
                {`${index + 1} · ${subject.tag}`}
              </Chip>
            ))}
          </div>
          <PlanTrainer key={subjectId} subject={SUBJECTS.find((item) => item.id === subjectId)!} onTerm={onTerm} />
        </>
      )}
    </div>
  );
}

function Method() {
  const steps = [
    ["1. Définir", "Souligne les mots du sujet et donne-leur le sens du cours, pas un sens vague."],
    ["2. Borner", "Temps, espace, acteurs. 1929-1939 n’est pas 1917-1945."],
    ["3. Trouver la tension", "Le sujet oppose presque toujours deux termes : crise / État, démocratie / modèle alternatif, alliés / antagonistes."],
    ["4. Une seule question", "Elle annonce le mouvement du plan sans recopier « I, II, III »."],
  ];
  return (
    <div className="space-y-3 px-4 py-4 text-sm">
      <h2 className="font-serif text-xl">Problématiser avant d’écrire</h2>
      {steps.map(([title, text]) => (
        <article key={title} className="rounded-2xl border border-line p-3">
          <p className="font-semibold">{title}</p>
          <p className="mt-1 text-muted">{text}</p>
        </article>
      ))}
      <article className="rounded-2xl bg-datebg p-3">
        <p className="font-semibold">Le jour J</p>
        <p className="mt-1">
          Deux sujets : un qui mélange les deux chapitres, un sur un seul chapitre, inconnu à l’avance. Entraîne les six plans, pas un seul.
        </p>
      </article>
    </div>
  );
}

function planToText(subject: RqpSubject) {
  const lines = [subject.question, "", subject.intro, ""];
  for (const part of subject.parts) {
    lines.push(part.title);
    for (const sub of part.subs) {
      lines.push("  " + sub.title);
      for (const detail of sub.details) lines.push("    • " + detail.replace(/\[\[|\]\]|\{\{|\}\}/g, ""));
    }
    lines.push("");
  }
  lines.push("Conclusion", subject.conclusion);
  return lines.join("\n");
}

function PlanTrainer({
  subject,
  onTerm,
}: {
  subject: RqpSubject;
  onTerm: (label: string) => void;
}) {
  const { drafts, setDraft } = useMemory();
  const [step, setStep] = useState(0);
  const [copied, setCopied] = useState(false);
  const labels = ["Afficher la réponse", "Défiler la réponse", "Défiler la réponse", "Masquer et recommencer"];
  const draft = drafts[subject.id] ?? "";

  function advance() {
    setStep((value) => (value >= 3 ? 0 : value + 1));
  }

  return (
    <article className="mx-4 mt-3 mb-6 rounded-3xl border border-line p-4">
      <p className={"inline-block rounded-full px-2 py-0.5 text-xs font-semibold " + (subject.tag === "Mixte" ? "bg-geobg text-geo" : subject.tag === "Chapitre 1" ? "bg-crisisbg text-crisis" : "bg-terrorbg text-terror")}>
        {subject.tag}
      </p>
      <h2 className="mt-2 font-serif text-xl">{subject.question}</h2>
      <p className="mt-3 text-xs font-semibold tracking-wide text-muted uppercase">Définis d’abord</p>
      <div className="mt-1 flex flex-wrap gap-1.5">
        {subject.define.map((word) => (
          <button key={word} type="button" onClick={() => onTerm(word)} className="rounded-full bg-paper px-2 py-1 text-xs font-semibold text-crisis">
            {word}
          </button>
        ))}
      </div>
      <label className="mt-3 block text-sm font-semibold" htmlFor={"brouillon-" + subject.id}>
        Ton brouillon, avant de regarder
      </label>
      <textarea
        id={"brouillon-" + subject.id}
        value={draft}
        onChange={(event) => setDraft(subject.id, event.target.value)}
        placeholder="Problématique, puis I, II, III. N’ouvre pas la réponse tout de suite."
        rows={4}
        className="mt-1 w-full rounded-xl border border-line bg-paper p-3 text-sm outline-none"
      />
      <button type="button" onClick={advance} className="mt-3 min-h-11 w-full rounded-xl bg-crisis text-sm font-semibold text-sheet">
        {labels[step]}
      </button>
      <div className="mt-2 grid grid-cols-4 gap-1">
        {["Caché", "Intro", "Sous-parties", "Détail"].map((label, index) => (
          <button
            key={label}
            type="button"
            onClick={() => setStep(index)}
            className={"min-h-9 rounded-lg text-xs font-semibold " + (step === index ? "bg-ink text-sheet" : "bg-paper text-muted")}
          >
            {label}
          </button>
        ))}
      </div>

      {step >= 1 && (
        <div className="mt-4 border-t border-line pt-3 text-sm">
          <p className="font-semibold text-crisis">Introduction</p>
          <p className="mt-1">
            <Rich text={subject.intro} onTerm={onTerm} />
          </p>
          <div className="mt-3 space-y-3">
            {subject.parts.map((part) => (
              <div key={part.title}>
                <p className="font-semibold">{part.title}</p>
                {step >= 2 &&
                  part.subs.map((sub) => (
                    <div key={sub.title} className="mt-1 pl-3">
                      <p>{sub.title}</p>
                      {step >= 3 && (
                        <ul className="mt-1 space-y-1 pl-3 text-muted">
                          {sub.details.map((detail) => (
                            <li key={detail}>
                              <Rich text={detail} onTerm={onTerm} />
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  ))}
              </div>
            ))}
          </div>
          {step >= 3 && (
            <div className="mt-4 rounded-xl bg-demobg p-3">
              <p className="font-semibold text-demo">Conclusion</p>
              <p className="mt-1">{subject.conclusion}</p>
              <button
                type="button"
                onClick={async () => {
                  try {
                    await navigator.clipboard.writeText(planToText(subject));
                    setCopied(true);
                    window.setTimeout(() => setCopied(false), 1600);
                  } catch {
                    setCopied(false);
                  }
                }}
                className="mt-2 text-sm font-semibold underline"
              >
                {copied ? "Plan copié" : "Copier le plan complet"}
              </button>
            </div>
          )}
        </div>
      )}
    </article>
  );
}

function Qcm({ items, title }: { items: QuizItem[]; title: string }) {
  const { grade } = useMemory();
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [missed, setMissed] = useState<QuizItem[]>([]);
  const [done, setDone] = useState(false);
  const item = items[index];

  function restart() {
    setIndex(0);
    setPicked(null);
    setScore(0);
    setMissed([]);
    setDone(false);
  }

  if (items.length === 0) return null;
  if (done) {
    return (
      <div className="px-4 py-4">
        <h2 className="font-serif text-2xl">
          {score} / {items.length}
        </h2>
        <p className="text-sm text-muted">{title}</p>
        {missed.length > 0 && (
          <ul className="mt-3 space-y-2 text-sm">
            {missed.map((question) => (
              <li key={question.id} className="rounded-xl bg-terrorbg p-3">
                <p className="font-semibold">{question.q}</p>
                <p className="mt-1">{question.choices[question.answer]}</p>
              </li>
            ))}
          </ul>
        )}
        <button type="button" onClick={restart} className="mt-4 min-h-11 w-full rounded-xl bg-ink text-sm font-semibold text-sheet">
          Recommencer
        </button>
      </div>
    );
  }

  return (
    <div className="px-4 py-4">
      <p className="text-xs text-muted">
        {title} · {index + 1} / {items.length}
      </p>
      <h2 className="mt-1 font-serif text-xl">{item.q}</h2>
      <div className="mt-3 grid gap-2">
        {item.choices.map((choice, choiceIndex) => {
          const revealed = picked !== null;
          const correct = choiceIndex === item.answer;
          const selected = picked === choiceIndex;
          let tone = "border-line bg-sheet";
          if (revealed && correct) tone = "border-demo bg-demobg";
          else if (revealed && selected) tone = "border-terror bg-terrorbg";
          return (
            <button
              key={choice}
              type="button"
              disabled={revealed}
              onClick={() => {
                setPicked(choiceIndex);
                const ok = choiceIndex === item.answer;
                if (ok) setScore((value) => value + 1);
                else setMissed((value) => [...value, item]);
                grade("qcm:" + item.id, ok ? "ok" : "again");
              }}
              className={"min-h-12 rounded-xl border px-3 py-2 text-left text-sm font-semibold " + tone}
            >
              {choice}
            </button>
          );
        })}
      </div>
      {picked !== null && (
        <>
          <p className="mt-3 rounded-xl bg-paper p-3 text-sm">{item.why}</p>
          <button
            type="button"
            onClick={() => {
              if (index + 1 >= items.length) setDone(true);
              else {
                setIndex((value) => value + 1);
                setPicked(null);
              }
            }}
            className="mt-3 min-h-11 w-full rounded-xl bg-ink text-sm font-semibold text-sheet"
          >
            {index + 1 >= items.length ? "Voir le score" : "Question suivante"}
          </button>
        </>
      )}
    </div>
  );
}

function Shell() {
  const [tab, setTab] = useState<Tab>("cours");
  const [termQuery, setTermQuery] = useState("");
  const { grades } = useMemory();
  const ok = Object.values(grades).filter((grade) => grade === "ok").length;
  const again = Object.values(grades).filter((grade): grade is Grade => grade === "again").length;

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [tab]);

  function openTerm(label: string) {
    setTermQuery(label);
    setTab("mots");
  }

  const tabs: { id: Tab; label: string; icon: typeof BookOpen }[] = [
    { id: "cours", label: "Cours", icon: BookOpen },
    { id: "dates", label: "Dates", icon: CalendarDays },
    { id: "mots", label: "Mots", icon: Library },
    { id: "recits", label: "Récits", icon: ScrollText },
    { id: "rqp", label: "Plans", icon: PenLine },
  ];

  return (
    <div className="min-h-dvh bg-paper text-ink">
      <div className="mx-auto min-h-dvh max-w-md bg-sheet">
        <header className="sticky top-0 z-20 border-b border-line bg-sheet/95 px-4 py-3 backdrop-blur">
          <p className="text-xs font-semibold tracking-wide text-crisis uppercase">Terminale · Thème 1</p>
          <h1 className="font-serif text-2xl">Crise & totalitarismes</h1>
          <p className="text-sm text-muted">
            {ok} sus · {again} à revoir
          </p>
        </header>
        <main className="pb-28">
          {tab === "cours" && <Cours onTerm={openTerm} />}
          {tab === "dates" && <Dates />}
          {tab === "mots" && <Mots query={termQuery} onQuery={setTermQuery} />}
          {tab === "recits" && <Recits />}
          {tab === "rqp" && <Rqp onTerm={openTerm} />}
        </main>
        <nav className="safe-bottom fixed bottom-0 left-1/2 z-30 flex w-full max-w-md -translate-x-1/2 border-t border-line bg-sheet" aria-label="Sections">
          {tabs.map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                className={"flex min-h-16 flex-1 flex-col items-center justify-center gap-0.5 text-xs font-semibold " + (active ? "text-crisis" : "text-muted")}
              >
                <Icon className="size-5" />
                {item.label}
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}

export function StudyApp() {
  return (
    <MemoryProvider>
      <Shell />
    </MemoryProvider>
  );
}
