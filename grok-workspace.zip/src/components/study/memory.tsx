import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Grade = "ok" | "again";

type Mem = {
  grades: Record<string, Grade>;
  drafts: Record<string, string>;
};

const EMPTY: Mem = { grades: {}, drafts: {} };

type Api = Mem & {
  ready: boolean;
  grade: (id: string, g: Grade) => void;
  setDraft: (id: string, text: string) => void;
  reset: () => void;
};

const Ctx = createContext<Api | null>(null);

export function MemoryProvider({ children }: { children: ReactNode }) {
  const [mem, setMem] = useState<Mem>(EMPTY);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("htg-memoire");
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<Mem>;
        setMem({
          grades: parsed.grades ?? {},
          drafts: parsed.drafts ?? {},
        });
      }
    } catch {
      /* ignore broken storage */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem("htg-memoire", JSON.stringify(mem));
  }, [mem, ready]);

  const api: Api = {
    ...mem,
    ready,
    grade: (id, g) =>
      setMem((m) => ({ ...m, grades: { ...m.grades, [id]: g } })),
    setDraft: (id, text) =>
      setMem((m) => ({ ...m, drafts: { ...m.drafts, [id]: text } })),
    reset: () => setMem(EMPTY),
  };

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}

export function useMemory() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("Mémoire de révision indisponible");
  return ctx;
}
